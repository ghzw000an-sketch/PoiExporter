package iq.gis.poiexporter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;
import java.util.Set;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Catalog;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.LayerData;

/** The full-screen pages reachable from the side menu. */
public final class Pages {
    private final MainActivity a;
    private EditText centerField;
    private TextView infoView, formatsView;
    private boolean silent;

    Pages(MainActivity a) {
        this.a = a;
    }

    // ------------------------------------------------------------------ small builders

    private LinearLayout col() {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private TextView head(String s) {
        TextView t = Ui.text(a, s, 16, Theme.text, true);
        t.setPadding(0, 0, 0, Ui.dp(a, 8));
        return t;
    }

    private TextView note(String s) {
        TextView t = Ui.text(a, s, 12.5f, Theme.sub, false);
        t.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 4));
        return t;
    }

    private TextView label(String s) {
        TextView t = Ui.text(a, s, 13, Theme.sub, false);
        t.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 4));
        return t;
    }

    private View toggle(String text, boolean on, final java.util.function.Consumer<Boolean> cb) {
        final boolean[] st = {on};
        LinearLayout r = Ui.row(a);
        r.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
        r.setClickable(true);
        final TextView box = Ui.text(a, on ? "☑" : "☐", 22, on ? Theme.primary : Theme.sub, true);
        TextView t = Ui.text(a, text, 14.5f, Theme.text, false);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.setMargins(Ui.dp(a, 10), 0, 0, 0);
        r.addView(box, new LinearLayout.LayoutParams(Ui.dp(a, 30), -2));
        r.addView(t, tl);
        Ui.pressable(r);
        r.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                st[0] = !st[0];
                box.setText(st[0] ? "☑" : "☐");
                box.setTextColor(st[0] ? Theme.primary : Theme.sub);
                box.animate().scaleX(1.25f).scaleY(1.25f).setDuration(90).withEndAction(new Runnable() {
                    public void run() {
                        box.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
                    }
                }).start();
                cb.accept(st[0]);
            }
        });
        return r;
    }

    static String folderName(String uri) {
        try {
            String id = Uri.parse(uri).getLastPathSegment();
            return id == null ? uri : id.replace(':', '/');
        } catch (Exception e) {
            return uri;
        }
    }

    private static double num(String s, double def) {
        try {
            return Double.parseDouble(s.trim().replace(',', '.'));
        } catch (Exception e) {
            return def;
        }
    }

    // ------------------------------------------------------------------ shape & size (shared)

    private final boolean[] kmUnit = {true};

    private void shapeSize(final LinearLayout box) {
        box.removeAllViews();
        final int shape = a.prefs.shape();
        box.addView(label(S.t("نوع المنطقة المحددة", "Selection shape")));
        LinearLayout ch = Ui.chips(a, new String[]{S.t("مستطيل", "Rectangle"), S.t("مربع", "Square"), S.t("دائرة", "Circle")},
                shape, new Ui.OnPick() {
                    public void pick(int i) {
                        a.prefs.shape(i);
                        a.applyArea(false);
                        shapeSize(box);
                    }
                });
        box.addView(ch, new LinearLayout.LayoutParams(-1, -2));
        box.addView(label(S.t("الوحدة", "Unit")));
        box.addView(Ui.chips(a, new String[]{S.t("كيلومتر", "Kilometres"), S.t("متر", "Metres")}, kmUnit[0] ? 0 : 1,
                new Ui.OnPick() {
                    public void pick(int i) {
                        kmUnit[0] = i == 0;
                        shapeSize(box);
                    }
                }), new LinearLayout.LayoutParams(-1, -2));
        final double f = kmUnit[0] ? 1000 : 1;
        final EditText w = Ui.field(a, "", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        w.setText(trim(a.prefs.width() / f));
        box.addView(label(shape == 2 ? S.t("نصف القطر", "Radius")
                : shape == 1 ? S.t("طول الضلع", "Side length") : S.t("العرض (شرق – غرب)", "Width (east–west)")));
        box.addView(w, new LinearLayout.LayoutParams(-1, -2));
        final EditText h = Ui.field(a, "", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        h.setText(trim(a.prefs.height() / f));
        if (shape == 0) {
            box.addView(label(S.t("الطول (شمال – جنوب)", "Height (north–south)")));
            box.addView(h, new LinearLayout.LayoutParams(-1, -2));
        }
        if (shape != 2) {
            box.addView(label(S.t("الاتجاه (دوران 0–360°)", "Rotation (0–360°)")));
            final EditText rf = Ui.field(a, "0", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            rf.setText(trim(a.prefs.rot()));
            rf.setGravity(Gravity.CENTER);
            rf.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int st, int c, int af) {
                }

                public void onTextChanged(CharSequence s, int st, int b, int c) {
                }

                public void afterTextChanged(Editable e) {
                    a.prefs.rot(num(e.toString(), 0));
                    a.applyArea(false);
                }
            });
            LinearLayout rr = Ui.row(a);
            rr.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            rr.addView(Ui.button(a, "−15°", false, new Runnable() {
                public void run() {
                    rf.setText(trim(((a.prefs.rot() - 15) % 360 + 360) % 360));
                }
            }), new LinearLayout.LayoutParams(Ui.dp(a, 80), -2));
            rr.addView(rf, Ui.lp(0, -2, 1f, a, 6, 0, 6, 0));
            rr.addView(Ui.button(a, "+15°", false, new Runnable() {
                public void run() {
                    rf.setText(trim((a.prefs.rot() + 15) % 360));
                }
            }), new LinearLayout.LayoutParams(Ui.dp(a, 80), -2));
            box.addView(rr);
            box.addView(note(S.t("على الخريطة: اسحب المقبض الأزرق ↻ فوق المنطقة لتدويرها.", "On the map: drag the blue ↻ handle above the area to rotate it.")));
        }
        TextWatcher tw = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                double wm = Math.max(10, Math.min(5.0e7, num(w.getText().toString(), a.prefs.width() / f) * f));
                double hm = Math.max(10, Math.min(5.0e7, num(h.getText().toString(), a.prefs.height() / f) * f));
                if (shape != 0) hm = wm;
                a.prefs.size(wm, shape == 0 ? hm : Math.max(a.prefs.height(), 10));
                if (shape != 0) a.prefs.size(wm, wm);
                a.applyArea(false);
            }
        };
        w.addTextChangedListener(tw);
        h.addTextChangedListener(tw);
    }

    private static String trim(double v) {
        String s = String.format(Locale.US, "%.4f", v);
        s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }

    // ------------------------------------------------------------------ settings

    View settings() {
        LinearLayout p = col();
        LinearLayout c = Ui.card(a);
        c.addView(head(S.t("المظهر", "Appearance")));
        c.addView(label(S.t("الثيم", "Theme")));
        c.addView(Ui.chips(a, new String[]{S.t("النظام", "System"), S.t("فاتح", "Light"), S.t("داكن", "Dark")},
                a.prefs.theme(), new Ui.OnPick() {
                    public void pick(int i) {
                        a.prefs.theme(i);
                        MainActivity.RESTORE_PAGE = "settings";
                        a.recreate();
                    }
                }), new LinearLayout.LayoutParams(-1, -2));
        c.addView(label(S.t("اللغة", "Language")));
        c.addView(Ui.chips(a, new String[]{"العربية", "English"}, a.prefs.arabic() ? 0 : 1, new Ui.OnPick() {
            public void pick(int i) {
                a.prefs.arabic(i == 0);
                MainActivity.RESTORE_PAGE = "settings";
                a.recreate();
            }
        }), new LinearLayout.LayoutParams(-1, -2));
        p.addView(c);

        c.addView(toggle(S.t("إبقاء الشاشة مضاءة أثناء العمل", "Keep screen on while working"), a.prefs.flag("awake", true),
                new java.util.function.Consumer<Boolean>() {
                    public void accept(Boolean on) {
                        a.prefs.setFlag("awake", on);
                        if (on) a.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        else a.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                }));
        LinearLayout f = Ui.card(a);
        f.addView(head(S.t("مجلد الحفظ", "Save folder")));
        final String cur = a.prefs.folder();
        f.addView(note(cur == null ? S.t("الافتراضي: التنزيلات / PoiExporter", "Default: Downloads / PoiExporter")
                : folderName(cur)));
        LinearLayout fr = Ui.row(a);
        fr.addView(Ui.button(a, S.t("اختيار مجلد", "Choose folder"), true, new Runnable() {
            public void run() {
                a.pickFolder();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 6, 4, 0));
        fr.addView(Ui.button(a, S.t("الافتراضي", "Default"), false, new Runnable() {
            public void run() {
                a.prefs.folder(null);
                a.showPage("settings");
            }
        }), Ui.lp(0, -2, 1f, a, 4, 6, 0, 0));
        f.addView(fr);
        p.addView(f);

        LinearLayout k = Ui.card(a);
        k.addView(head(S.t("نوع الإحداثيات", "Coordinate type")));
        k.addView(note(S.t("يُستخدم في عمود COORD وفي ملفات KML وفي نوافذ المعلومات.", "Used for the COORD column, KML files and info dialogs.")));
        final TextView ex = Ui.text(a, "", 13, Theme.accent, false);
        ex.setTextIsSelectable(true);
        k.addView(Ui.chips(a, new String[]{"DD", "DMS", "UTM", "MGRS"}, a.prefs.fmt(), new Ui.OnPick() {
            public void pick(int i) {
                a.prefs.fmt(i);
                ex.setText(example());
            }
        }), new LinearLayout.LayoutParams(-1, -2));
        ex.setText(example());
        ex.setPadding(0, Ui.dp(a, 8), 0, 0);
        k.addView(ex);
        p.addView(k);

        LinearLayout s = Ui.card(a);
        s.addView(head(S.t("المنطقة المحددة (افتراضي)", "Selection area (default)")));
        LinearLayout box = col();
        s.addView(box);
        shapeSize(box);
        p.addView(s);
        p.addView(resetCard(), Ui.lp(-1, -2, 0, a, 0, 6, 0, 16));
        return p;
    }

    private String example() {
        double[] c = a.prefs.center();
        return S.t("مثال لمركز المنطقة: ", "Example (area centre): ") + CoordFmt.format(a.fmt(), c[0], c[1]);
    }

    // ------------------------------------------------------------------ area

    View area() {
        LinearLayout p = col();
        LinearLayout c = Ui.card(a);
        c.addView(head(S.t("مركز المنطقة", "Area centre")));
        c.addView(note(S.t("اكتب الإحداثيات بأي صيغة: درجات عشرية أو DMS أو UTM أو MGRS (يُكتشف النوع تلقائياً).",
                "Type coordinates in any format: decimal, DMS, UTM or MGRS (auto-detected).")));
        centerField = Ui.field(a, "33.3152, 44.3661  |  38S 444000 3688000", InputType.TYPE_CLASS_TEXT);
        centerField.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        centerField.setGravity(Gravity.START);
        double[] cc = a.prefs.center();
        centerField.setText(CoordFmt.format(a.fmt(), cc[0], cc[1]));
        c.addView(centerField, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout r1 = Ui.row(a);
        r1.addView(Ui.button(a, S.t("تطبيق", "Apply"), true, new Runnable() {
            public void run() {
                try {
                    CoordFmt.Parsed ps = CoordFmt.parse(centerField.getText().toString());
                    a.setCenter(ps.lat, ps.lon);
                    a.zoomToArea();
                    a.toast(S.t("تم تحديد المركز (" + ps.fmt + ")", "Centre set (" + ps.fmt + ")"));
                } catch (Exception e) {
                    a.toast(S.t("إحداثيات غير صالحة", "Invalid coordinates"));
                }
            }
        }), Ui.lp(0, -2, 1f, a, 0, 8, 4, 0));
        r1.addView(Ui.button(a, S.t("من مركز الخريطة", "From map centre"), false, new Runnable() {
            public void run() {
                org.osmdroid.api.IGeoPoint g = a.map.getMapCenter();
                a.setCenter(g.getLatitude(), g.getLongitude());
            }
        }), Ui.lp(0, -2, 1f, a, 4, 8, 0, 0));
        c.addView(r1);
        c.addView(Ui.button(a, S.t("◎ من موقعي (GPS)", "◎ From my GPS location"), false, new Runnable() {
            public void run() {
                a.useLocationAsCenter();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
        formatsView = Ui.text(a, "", 13, Theme.accent, false);
        formatsView.setTextIsSelectable(true);
        formatsView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        formatsView.setPadding(0, Ui.dp(a, 10), 0, 0);
        c.addView(formatsView);
        p.addView(c);

        LinearLayout n = Ui.card(a);
        n.addView(head(S.t("تحريك المنطقة", "Nudge the area")));
        n.addView(note(S.t("كل ضغطة تحرّك المنطقة ربع حجمها. على الخريطة: اسحب المنطقة لتحريكها، واسحب النقاط الحمراء لتكبيرها وتصغيرها، أو اضغط مطوّلاً لنقل المركز.",
                "Each tap moves the area by a quarter of its size. On the map drag the area to move it, drag the red handles to resize, or long-press to re-centre.")));
        LinearLayout up = Ui.row(a);
        up.setGravity(Gravity.CENTER);
        up.addView(nudge("▲", 0, 1));
        n.addView(up);
        LinearLayout mid = Ui.row(a);
        mid.setGravity(Gravity.CENTER);
        mid.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        mid.addView(nudge("◀", -1, 0));
        mid.addView(nudge("⌖", 0, 0));
        mid.addView(nudge("▶", 1, 0));
        n.addView(mid);
        LinearLayout dn = Ui.row(a);
        dn.setGravity(Gravity.CENTER);
        dn.addView(nudge("▼", 0, -1));
        n.addView(dn);
        p.addView(n);

        LinearLayout s = Ui.card(a);
        s.addView(head(S.t("الشكل والأبعاد", "Shape & size")));
        LinearLayout box = col();
        s.addView(box);
        shapeSize(box);
        s.addView(Ui.button(a, S.t("عرض المنطقة على الخريطة", "Show area on map"), true, new Runnable() {
            public void run() {
                a.showMap();
                a.zoomToArea();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        p.addView(s);

        LinearLayout i = Ui.card(a);
        i.addView(head(S.t("معلومات المنطقة", "Area info")));
        infoView = Ui.text(a, "", 13, Theme.text, false);
        infoView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        infoView.setTextIsSelectable(true);
        i.addView(infoView);
        p.addView(i);
        refreshArea();
        return p;
    }

    private View nudge(String label, final int dx, final int dy) {
        View b = Ui.button(a, label, dx == 0 && dy == 0 ? false : true, new Runnable() {
            public void run() {
                AreaSpec s = a.area();
                double w = s.circle ? s.radius * 2 : s.widthM(), h = s.circle ? s.radius * 2 : s.heightM();
                double c[] = a.prefs.center();
                if (dx == 0 && dy == 0) {
                    a.zoomToArea();
                    return;
                }
                double dLat = dy * h * 0.25 / 111320.0;
                double dLon = dx * w * 0.25 / (111320.0 * Math.max(0.05, Math.cos(Math.toRadians(c[0]))));
                a.setCenter(c[0] + dLat, c[1] + dLon);
            }
        });
        b.setLayoutParams(Ui.lp(Ui.dp(a, 64), Ui.dp(a, 50), 0, a, 4, 4, 4, 4));
        return b;
    }

    void onAreaChanged() {
        refreshArea();
    }

    private void refreshArea() {
        if (centerField == null || !centerField.isAttachedToWindow()) return;
        AreaSpec s = a.area();
        double[] c = a.prefs.center();
        if (!centerField.hasFocus()) centerField.setText(CoordFmt.format(a.fmt(), c[0], c[1]));
        formatsView.setText("DD:   " + CoordFmt.dd(c[0], c[1]) + "\nDMS:  " + CoordFmt.dms(c[0], c[1]) + "\nUTM:  "
                + CoordFmt.utm(c[0], c[1]) + "\nMGRS: " + CoordFmt.format(CoordFmt.Fmt.MGRS, c[0], c[1]));
        StringBuilder sb = new StringBuilder();
        if (s.circle) sb.append("R = ").append(MainActivity.fmtLen(s.radius)).append('\n');
        else sb.append(MainActivity.fmtLen(s.widthM())).append(" × ").append(MainActivity.fmtLen(s.heightM())).append('\n');
        sb.append(String.format(Locale.US, "%.3f km²\n", s.areaKm2()));
        if (!s.circle) sb.append(String.format(Locale.US, "↻ %.1f°\n", s.rot));
        sb.append("SW: ").append(CoordFmt.format(a.fmt(), s.south, s.west)).append('\n');
        sb.append("NE: ").append(CoordFmt.format(a.fmt(), s.north, s.east));
        infoView.setText(sb.toString());
    }

    // ------------------------------------------------------------------ layers

    View layers() {
        LinearLayout p = col();

        final Set<String> poi = a.csv("poi", a.allPoi());
        LinearLayout c = Ui.card(a);
        c.addView(head(S.t("المعالم (حسب الفئة)", "Landmarks (by category)")));
        final LinearLayout list = col();
        LinearLayout ar = Ui.row(a);
        ar.addView(Ui.button(a, S.t("تحديد الكل", "All"), false, new Runnable() {
            public void run() {
                poi.clear();
                for (Catalog.PoiCat pc : Catalog.POI) poi.add(pc.id);
                a.saveCsv("poi", poi);
                a.showPage("layers");
            }
        }), Ui.lp(0, -2, 1f, a, 0, 0, 4, 6));
        ar.addView(Ui.button(a, S.t("إلغاء الكل", "None"), false, new Runnable() {
            public void run() {
                poi.clear();
                a.saveCsv("poi", poi);
                a.showPage("layers");
            }
        }), Ui.lp(0, -2, 1f, a, 4, 0, 0, 6));
        c.addView(ar);
        for (final Catalog.PoiCat pc : Catalog.POI) {
            c.addView(toggle(pc.label(S.ar), poi.contains(pc.id), new java.util.function.Consumer<Boolean>() {
                public void accept(Boolean on) {
                    if (on) poi.add(pc.id);
                    else poi.remove(pc.id);
                    a.saveCsv("poi", poi);
                }
            }));
        }
        p.addView(c);

        final Set<String> lay = a.csv("layers", "");
        LinearLayout o = Ui.card(a);
        o.addView(head(S.t("الطرق والمياه والسياحة", "Roads, water & tourism")));
        for (final Catalog.LayerDef d : Catalog.LAYERS) {
            o.addView(toggle(d.label(S.ar), lay.contains(d.id), new java.util.function.Consumer<Boolean>() {
                public void accept(Boolean on) {
                    if (on) lay.add(d.id);
                    else lay.remove(d.id);
                    a.saveCsv("layers", lay);
                }
            }));
        }
        p.addView(o);

        final Set<String> adm = a.csv("adm", "");
        LinearLayout ad = Ui.card(a);
        ad.addView(head(S.t("الحدود الإدارية", "Administrative boundaries")));
        for (int i = 0; i < 3; i++) {
            final String id = Catalog.ADMIN_IDS[i];
            ad.addView(toggle(Catalog.adminLabel(i, S.ar), adm.contains(id), new java.util.function.Consumer<Boolean>() {
                public void accept(Boolean on) {
                    if (on) adm.add(id);
                    else adm.remove(id);
                    a.saveCsv("adm", adm);
                }
            }));
        }
        ad.addView(note(S.t("رقم المستوى في OpenStreetMap (admin_level) للمحافظة / القضاء / الناحية. القيم الافتراضية 4 / 5 / 6 — عدّلها إن اختلفت في منطقتك.",
                "OpenStreetMap admin_level for governorate / qadaa / nahiya. Defaults 4 / 5 / 6 — change if your area differs.")));
        LinearLayout lv = Ui.row(a);
        lv.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        for (int i = 0; i < 3; i++) {
            final String key = "lv" + (i + 4);
            final EditText e = Ui.field(a, String.valueOf(i + 4), InputType.TYPE_CLASS_NUMBER);
            e.setText(a.prefs.get(key, String.valueOf(i + 4)));
            e.setGravity(Gravity.CENTER);
            e.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int st, int c1, int af) {
                }

                public void onTextChanged(CharSequence s, int st, int b, int c1) {
                }

                public void afterTextChanged(Editable ed) {
                    a.prefs.put(key, ed.toString());
                }
            });
            lv.addView(e, Ui.lp(0, -2, 1f, a, 4, 4, 4, 4));
        }
        ad.addView(lv);
        ad.addView(toggle(S.t("تعبئة الناحية والقضاء والمحافظة لكل معلم", "Fill NAHIYA / QADAA / GOVERNORAT for each feature"),
                a.prefs.flag("fillAdmin", true), new java.util.function.Consumer<Boolean>() {
                    public void accept(Boolean on) {
                        a.prefs.setFlag("fillAdmin", on);
                    }
                }));
        p.addView(ad);

        LinearLayout ex = Ui.card(a);
        ex.addView(head(S.t("خيارات إضافية", "Extra options")));
        ex.addView(toggle(S.t("تضمين المعالم بلا اسم", "Include unnamed features"), a.prefs.flag("unnamed", false),
                new java.util.function.Consumer<Boolean>() {
                    public void accept(Boolean on) {
                        a.prefs.setFlag("unnamed", on);
                    }
                }));
        ex.addView(label(S.t("فلتر مخصص (اختياري) مثل amenity=cafe", "Custom filter (optional), e.g. amenity=cafe")));
        final EditText cf = Ui.field(a, "key=value", InputType.TYPE_CLASS_TEXT);
        cf.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        cf.setText(a.prefs.get("custom", ""));
        cf.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c1, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c1) {
            }

            public void afterTextChanged(Editable ed) {
                a.prefs.put("custom", ed.toString());
            }
        });
        ex.addView(cf, new LinearLayout.LayoutParams(-1, -2));
        p.addView(ex);

        p.addView(Ui.button(a, S.t("⬇ تحميل الآن", "⬇ Download now"), true, new Runnable() {
            public void run() {
                a.showMap();
                a.download();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        return p;
    }

    // ------------------------------------------------------------------ saved landmarks & layers

    private int libTab;
    private String libQuery = "";
    private TextView statGroups, statPoints, statHidden;

    private String geomGlyph(LayerData l) {
        return l.geom == iq.gis.poiexporter.core.Feature.POINT ? "📍"
                : l.geom == iq.gis.poiexporter.core.Feature.LINE ? "〰" : "⬠";
    }

    private View stat(String label, TextView value) {
        LinearLayout s = col();
        s.setGravity(Gravity.CENTER);
        value.setGravity(Gravity.CENTER);
        s.addView(value);
        TextView l = Ui.text(a, label, 11.5f, 0xCCFFFFFF, false);
        l.setGravity(Gravity.CENTER);
        s.addView(l);
        return s;
    }

    private void refreshStats() {
        if (statGroups == null) return;
        int pts = 0, hid = 0;
        for (LayerData l : MainActivity.LIB) {
            pts += l.features.size();
            if (MainActivity.HIDDEN.contains(l.id)) hid++;
        }
        statGroups.setText(String.valueOf(MainActivity.LIB.size()));
        statPoints.setText(String.valueOf(pts));
        statHidden.setText(String.valueOf(hid));
    }

    View library() {
        LinearLayout p = col();

        // header card with live statistics
        LinearLayout hero = col();
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{Theme.primary, 0xFF2B6F8A});
        gd.setCornerRadius(Ui.dp(a, 22));
        hero.setBackground(gd);
        hero.setElevation(Ui.dp(a, 3));
        hero.setPadding(Ui.dp(a, 18), Ui.dp(a, 16), Ui.dp(a, 18), Ui.dp(a, 14));
        TextView ht = Ui.text(a, "📁  " + S.t("المعالم المحفوظة", "Saved landmarks"), 20, Color.WHITE, true);
        hero.addView(ht);
        hero.addView(Ui.text(a, S.t("مجموعاتك ونقاطك وطرقك في مكان واحد", "Your groups, points and routes in one place"),
                12.5f, 0xD9FFFFFF, false));
        statGroups = Ui.text(a, "0", 24, Color.WHITE, true);
        statPoints = Ui.text(a, "0", 24, Color.WHITE, true);
        statHidden = Ui.text(a, "0", 24, Color.WHITE, true);
        LinearLayout st = Ui.row(a);
        st.addView(stat(S.t("مجموعات", "Groups"), statGroups), new LinearLayout.LayoutParams(0, -2, 1f));
        st.addView(stat(S.t("نقاط", "Points"), statPoints), new LinearLayout.LayoutParams(0, -2, 1f));
        st.addView(stat(S.t("مخفية", "Hidden"), statHidden), new LinearLayout.LayoutParams(0, -2, 1f));
        hero.addView(st, Ui.lp(-1, -2, 0, a, 0, 14, 0, 12));
        LinearLayout hb = Ui.row(a);
        hb.addView(Ui.button(a, S.t("＋ مجموعة جديدة", "＋ New group"), true, Color.WHITE, Theme.primary, new Runnable() {
            public void run() {
                newGroupDialog();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 0, 4, 0));
        hb.addView(Ui.button(a, S.t("⬆ استيراد", "⬆ Import"), false, Color.WHITE, Color.WHITE, new Runnable() {
            public void run() {
                a.pickImport();
            }
        }), Ui.lp(0, -2, 1f, a, 4, 0, 0, 0));
        hero.addView(hb);
        p.addView(hero, Ui.lp(-1, -2, 0, a, 0, 4, 0, 8));

        // search + tabs
        final EditText q = Ui.field(a, S.t("🔍 ابحث عن مجموعة أو معلم…", "🔍 Search a group or landmark…"), InputType.TYPE_CLASS_TEXT);
        q.setText(libQuery);
        p.addView(q, Ui.lp(-1, -2, 0, a, 0, 4, 0, 6));
        final LinearLayout list = col();
        Ui.OnPick tabPick = new Ui.OnPick() {
            public void pick(int i) {
                libTab = i;
                renderLibrary(list);
            }
        };
        p.addView(Ui.chips(a, new String[]{S.t("المجموعات (", "Groups (") + MainActivity.LIB.size() + ")",
                S.t("الطبقات المحمّلة (", "Downloaded (") + MainActivity.DL.size() + ")"}, libTab, tabPick),
                new LinearLayout.LayoutParams(-1, -2));
        p.addView(list);
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                libQuery = e.toString().trim();
                renderLibrary(list);
            }
        });
        renderLibrary(list);
        refreshStats();
        return p;
    }

    private boolean matches(LayerData l) {
        if (libQuery.isEmpty()) return true;
        String k = libQuery.toLowerCase(Locale.ROOT);
        if (l.label.toLowerCase(Locale.ROOT).contains(k)) return true;
        for (iq.gis.poiexporter.core.Feature f : l.features) {
            if (f.name.toLowerCase(Locale.ROOT).contains(k)) return true;
        }
        return false;
    }

    private void renderLibrary(LinearLayout list) {
        list.removeAllViews();
        boolean groups = libTab == 0;
        java.util.List<LayerData> src = new java.util.ArrayList<>(groups ? MainActivity.LIB : MainActivity.DL);
        int shown = 0;
        for (LayerData l : src) {
            if (!matches(l)) continue;
            list.addView(groupCard(l, groups));
            shown++;
        }
        if (shown == 0) {
            LinearLayout e = col();
            e.setGravity(Gravity.CENTER);
            e.setPadding(Ui.dp(a, 10), Ui.dp(a, 36), Ui.dp(a, 10), Ui.dp(a, 20));
            TextView em = Ui.text(a, groups ? "🗂" : "☁", 46, Theme.sub, false);
            em.setGravity(Gravity.CENTER);
            e.addView(em);
            String msg = !libQuery.isEmpty() ? S.t("لا توجد نتائج مطابقة", "No matching results")
                    : groups ? S.t("لا توجد مجموعات بعد.\nاضغط ⚑ على الخريطة لإضافة معلم، أو اضغط مطوّلاً لإنشاء مجموعة.",
                            "No groups yet.\nTap ⚑ on the map to add a landmark, or long-press to create a group.")
                    : S.t("لا توجد طبقات محمّلة.\nاستخدم زر ⬇ للتحميل.", "No downloaded layers.\nUse the ⬇ button.");
            TextView mt = Ui.text(a, msg, 13.5f, Theme.sub, false);
            mt.setGravity(Gravity.CENTER);
            mt.setPadding(0, Ui.dp(a, 8), 0, 0);
            e.addView(mt);
            list.addView(e);
        }
    }

    private View iconBtn(String glyph, int tint, final Runnable r) {
        TextView t = Ui.text(a, glyph, 18, tint, false);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        t.setBackground(Ui.stroke(Theme.field, Theme.line, 12, a));
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                r.run();
            }
        });
        t.setLayoutParams(Ui.lp(0, Ui.dp(a, 42), 1f, a, 3, 0, 3, 0));
        return t;
    }

    private View groupCard(final LayerData l, final boolean group) {
        final LinearLayout c = Ui.card(a);
        boolean hidden = MainActivity.HIDDEN.contains(l.id);
        c.setAlpha(hidden ? 0.6f : 1f);

        LinearLayout top = Ui.row(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView av = Ui.text(a, geomGlyph(l), 22, Color.WHITE, false);
        av.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable ag = new android.graphics.drawable.GradientDrawable();
        ag.setCornerRadius(Ui.dp(a, 14));
        ag.setColor(FeatureOverlay.colorOf(l));
        av.setBackground(ag);
        top.addView(av, Ui.lp(Ui.dp(a, 48), Ui.dp(a, 48), 0, a, 0, 0, 12, 0));
        LinearLayout tcol = col();
        tcol.setClickable(true);
        TextView title = Ui.text(a, l.label, 15.5f, Theme.text, true);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tcol.addView(title);
        StringBuilder sub = new StringBuilder();
        sub.append(l.features.size()).append(' ').append(S.t("عنصر", "items")).append("  •  ").append(LayerData.geomName(l.geom));
        if (group && l.id.equals(MainActivity.ACTIVE)) sub.append("  •  ★ ").append(S.t("نشطة", "active"));
        tcol.addView(Ui.text(a, sub.toString(), 12, Theme.sub, false));
        tcol.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                a.marks.groupSheet(l);
            }
        });
        top.addView(tcol, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(Ui.toggleSwitch(a, !hidden, new java.util.function.Consumer<Boolean>() {
            public void accept(Boolean on) {
                if (on) MainActivity.HIDDEN.remove(l.id);
                else MainActivity.HIDDEN.add(l.id);
                a.saveCsv("hidden", MainActivity.HIDDEN);
                a.rebuild();
                c.setAlpha(on ? 1f : 0.6f);
                refreshStats();
            }
        }));
        c.addView(top);

        LinearLayout acts = Ui.row(a);
        acts.addView(iconBtn("🔍", Theme.primary, new Runnable() {
            public void run() {
                a.previewDialog(l);
            }
        }));
        acts.addView(iconBtn("☰", Theme.primary, new Runnable() {
            public void run() {
                a.marks.pointsManager(l);
            }
        }));
        acts.addView(iconBtn("🎨", 0xFFFB8C00, new Runnable() {
            public void run() {
                a.marks.colorDialog(l.color, true, new Landmarks.ColorCb() {
                    public void picked(int color, boolean all) {
                        l.color = color;
                        if (all) for (iq.gis.poiexporter.core.Feature f : l.features) f.color = 0;
                        if (Library.isGroup(l)) a.persist(l);
                        a.rebuild();
                        a.showPage("library");
                    }
                });
            }
        }));
        acts.addView(iconBtn("⤴", Theme.primary, new Runnable() {
            public void run() {
                a.shareDialog(l);
            }
        }));
        acts.addView(iconBtn("⋯", Theme.text, new Runnable() {
            public void run() {
                a.marks.groupSheet(l);
            }
        }));
        c.addView(acts, Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        if (!group) {
            c.addView(Ui.button(a, S.t("💾 حفظ كمجموعة", "💾 Save as group"), true, new Runnable() {
                public void run() {
                    a.saveAsGroup(l);
                }
            }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        }
        return c;
    }

    // ------------------------------------------------------------------ online maps

    private int newMapKind;

    View maps() {
        LinearLayout p = col();
        final java.util.List<MapSources.Item> items = MapSources.load(a.prefs);

        LinearLayout add = Ui.card(a);
        add.addView(head("🌐  " + S.t("إضافة خريطة من الإنترنت", "Add a map from the internet")));
        add.addView(note(S.t("الصق رابط البلاطات بصيغة XYZ مثل: https://example.com/{z}/{x}/{y}.png (يدعم {s} و {-y}). أضفها كخريطة أساسية، أو كطبقة للعرض فقط تظهر فوق الخريطة بشفافية تتحكم بها.",
                "Paste an XYZ tile link such as https://example.com/{z}/{x}/{y}.png (supports {s} and {-y}). Add it as a base map, or as a view-only layer drawn over the map with adjustable opacity.")));
        final EditText nm = Ui.field(a, S.t("اسم الخريطة", "Map name"), InputType.TYPE_CLASS_TEXT);
        final EditText url = Ui.field(a, "https://…/{z}/{x}/{y}.png", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        url.setGravity(Gravity.START);
        add.addView(nm, Ui.lp(-1, -2, 0, a, 0, 6, 0, 4));
        add.addView(url, Ui.lp(-1, -2, 0, a, 0, 4, 0, 6));
        final int[] kind = {newMapKind};
        add.addView(Ui.chips(a, new String[]{S.t("خريطة أساسية", "Base map"), S.t("طبقة للعرض فقط", "View-only layer")},
                newMapKind, new Ui.OnPick() {
                    public void pick(int i) {
                        kind[0] = i;
                        newMapKind = i;
                    }
                }), new LinearLayout.LayoutParams(-1, -2));
        add.addView(label(S.t("مصادر جاهزة (اضغط لتعبئة الحقول)", "Ready sources (tap to fill)")));
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout pr = Ui.row(a);
        for (final MapSources.Preset ps : MapSources.PRESETS) {
            TextView ch = Ui.chip(a, ps.label());
            ch.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    nm.setText(ps.label());
                    url.setText(ps.url);
                    newMapKind = ps.overlay ? 1 : 0;
                    kind[0] = newMapKind;
                }
            });
            pr.addView(ch, Ui.lp(-2, -2, 0, a, 3, 3, 3, 3));
        }
        hs.addView(pr);
        add.addView(hs);
        add.addView(Ui.button(a, S.t("＋ إضافة الخريطة", "＋ Add map"), true, new Runnable() {
            public void run() {
                String u = url.getText().toString().trim();
                if (!MapSources.validUrl(u)) {
                    a.toast(S.t("الرابط يجب أن يبدأ بـ http(s) ويحوي {z} و {x} و {y}", "The link must start with http(s) and contain {z}, {x} and {y}"));
                    return;
                }
                MapSources.Item it = new MapSources.Item();
                it.id = "m" + System.currentTimeMillis();
                String n = nm.getText().toString().trim();
                it.name = n.isEmpty() ? S.t("خريطة ", "Map ") + (items.size() + 1) : n;
                it.url = u;
                it.overlay = kind[0] == 1;
                it.maxZ = 19;
                for (MapSources.Preset ps : MapSources.PRESETS) if (ps.url.equals(u)) it.maxZ = ps.maxZ;
                items.add(it);
                MapSources.save(a.prefs, items);
                a.applyMapOverlays();
                a.toast(S.t("تمت إضافة: ", "Added: ") + it.name);
                a.showPage("maps");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        p.addView(add);

        LinearLayout mine = Ui.card(a);
        mine.addView(head(S.t("خرائطي", "My maps") + "  (" + items.size() + ")"));
        if (items.isEmpty()) mine.addView(note(S.t("لم تضف أي خريطة بعد.", "No maps added yet.")));
        p.addView(mine);
        String curBase = a.prefs.get("basemap", "0");
        for (final MapSources.Item it : new java.util.ArrayList<>(items)) p.addView(mapCard(it, items, curBase));

        LinearLayout st = Ui.card(a);
        st.addView(head(S.t("التخزين دون اتصال", "Offline storage")));
        long sz = MapSources.dirSize(new java.io.File(a.getFilesDir(), "osmdroid"));
        st.addView(note(S.t("حجم الخرائط المخزنة على الجهاز: ", "Maps stored on this device: ") + MapSources.fmtBytes(sz)));
        st.addView(Ui.button(a, S.t("🗑 مسح الخرائط المخزنة", "🗑 Clear stored maps"), false, Theme.danger, Theme.danger, new Runnable() {
            public void run() {
                a.message(S.t("مسح الخرائط المخزنة", "Clear stored maps"),
                        S.t("سيتم حذف كل البلاطات المخزنة (بما فيها المنزّلة للعمل دون إنترنت). تبقى الخرائط المضافة في القائمة.",
                                "All stored tiles (including offline downloads) will be deleted. Added maps stay in the list."),
                        S.t("مسح", "Clear"), new Runnable() {
                            public void run() {
                                a.clearTileCache();
                            }
                        });
            }
        }), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
        p.addView(st);
        return p;
    }

    private View mapCard(final MapSources.Item it, final java.util.List<MapSources.Item> items, String curBase) {
        LinearLayout c = Ui.card(a);
        LinearLayout top = Ui.row(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout tc = col();
        TextView t = Ui.text(a, (it.overlay ? "🧩 " : "🗺 ") + it.name, 15.5f, Theme.text, true);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tc.addView(t);
        TextView u = Ui.text(a, it.url, 11, Theme.sub, false);
        u.setSingleLine(true);
        u.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        u.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        tc.addView(u);
        tc.addView(Ui.text(a, it.overlay ? S.t("طبقة للعرض فقط", "View-only layer") : S.t("خريطة أساسية", "Base map"), 12, Theme.accent, false));
        top.addView(tc, new LinearLayout.LayoutParams(0, -2, 1f));
        if (it.overlay) {
            top.addView(Ui.toggleSwitch(a, it.visible, new java.util.function.Consumer<Boolean>() {
                public void accept(Boolean on) {
                    it.visible = on;
                    MapSources.save(a.prefs, items);
                    a.applyMapOverlays();
                }
            }));
        }
        c.addView(top);
        if (it.overlay) {
            c.addView(label(S.t("الشفافية: ", "Opacity: ") + it.opacity + "%"));
            final android.widget.SeekBar sb = new android.widget.SeekBar(a);
            sb.setMax(100);
            sb.setProgress(it.opacity);
            sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Theme.primary));
            sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Theme.primary));
            sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(android.widget.SeekBar s, int v, boolean user) {
                    if (user) a.updateOverlayOpacity(it.id, Math.max(5, v));
                }

                public void onStartTrackingTouch(android.widget.SeekBar s) {
                }

                public void onStopTrackingTouch(android.widget.SeekBar s) {
                    it.opacity = Math.max(5, s.getProgress());
                    MapSources.save(a.prefs, items);
                    a.showPage("maps");
                }
            });
            c.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        } else {
            boolean on = curBase.equals("c:" + it.id);
            c.addView(Ui.button(a, on ? S.t("✔ مستخدمة الآن كخريطة أساسية", "✔ Currently the base map")
                    : S.t("استخدامها كخريطة أساسية", "Use as base map"), !on, new Runnable() {
                public void run() {
                    a.setBase("c:" + it.id, true);
                    a.showPage("maps");
                }
            }), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        }
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("⬇ تنزيل للعمل دون إنترنت", "⬇ Download for offline"), false, new Runnable() {
            public void run() {
                a.tileDownloadDialog(it);
            }
        }), Ui.lp(0, -2, 2f, a, 0, 8, 3, 0));
        r.addView(Ui.button(a, "🗑", false, Theme.danger, Theme.danger, new Runnable() {
            public void run() {
                a.message(S.t("حذف الخريطة", "Delete map"), S.t("حذف «", "Delete \u201c") + it.name + S.t("» من القائمة؟", "\u201d from the list?"),
                        S.t("حذف", "Delete"), new Runnable() {
                            public void run() {
                                items.remove(it);
                                MapSources.save(a.prefs, items);
                                if (a.prefs.get("basemap", "0").equals("c:" + it.id)) a.setBase("0", true);
                                a.applyMapOverlays();
                                a.showPage("maps");
                            }
                        });
            }
        }), Ui.lp(0, -2, 1f, a, 3, 8, 0, 0));
        c.addView(r);
        return c;
    }

    private View resetCard() {
        LinearLayout r = Ui.card(a);
        r.setBackground(Ui.stroke(Theme.card, Theme.danger, 16, a));
        r.addView(Ui.text(a, "⚠  " + S.t("إعادة ضبط البرنامج", "Reset the app"), 16, Theme.danger, true));
        r.addView(note(S.t("يمسح جميع محتويات البرنامج: المعالم والمجموعات والطبقات والخرائط المضافة والمخزنة والإعدادات، ويعيده كأنه جديد. لا يمكن التراجع، والملفات المصدّرة في مجلد الحفظ لا تتأثر.\n\nلتأكيد العملية اكتب كلمة «حذف» في الحقل ثم اضغط الزر. إن لم تكتبها فلن يُحذف شيء.",
                "Erases everything in the app: landmarks, groups, layers, added and stored maps and settings, as if it were new. This cannot be undone; exported files in your save folder are not touched.\n\nTo confirm, type the word \u201cحذف\u201d (or delete) in the box and press the button. If you do not type it, nothing is deleted.")));
        final EditText f = Ui.field(a, "حذف", InputType.TYPE_CLASS_TEXT);
        r.addView(f, Ui.lp(-1, -2, 0, a, 0, 6, 0, 6));
        r.addView(Ui.button(a, S.t("إعادة ضبط البرنامج", "Reset the app"), true, Theme.danger, Color.WHITE, new Runnable() {
            public void run() {
                String v = f.getText().toString().trim();
                if (v.equals("حذف") || v.equalsIgnoreCase("delete")) {
                    a.resetApp();
                } else {
                    a.toast(S.t("اكتب كلمة «حذف» أولاً لتأكيد إعادة الضبط", "Type the word \u201cحذف\u201d first to confirm"));
                }
            }
        }), new LinearLayout.LayoutParams(-1, -2));
        return r;
    }

    private void newGroupDialog() {
        LinearLayout box = col();
        box.addView(head(S.t("مجموعة جديدة", "New group")));
        final EditText f = Ui.field(a, S.t("اسم المجموعة", "Group name"), InputType.TYPE_CLASS_TEXT);
        box.addView(f);
        final android.app.Dialog d = a.card(box);
        box.addView(Ui.button(a, S.t("إنشاء", "Create"), true, new Runnable() {
            public void run() {
                String n = f.getText().toString().trim();
                if (n.isEmpty()) return;
                LayerData g = new LayerData(Library.newId(), n, iq.gis.poiexporter.core.Feature.POINT);
                MainActivity.LIB.add(g);
                MainActivity.ACTIVE = g.id;
                a.prefs.put("active", g.id);
                a.persist(g);
                d.dismiss();
                a.showPage("library");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
    }

    // ------------------------------------------------------------------ KML exchange

    View kml() {
        LinearLayout p = col();
        LinearLayout i = Ui.card(a);
        i.addView(head(S.t("بيني كويست (KML / KMZ)", "PineQuest (KML / KMZ)")));
        i.addView(note(S.t("صدّر المعالم كملف KML أو KMZ ثم افتحه في البرنامج عبر «مشاركة / فتح»، أو استورد ملفاً من البرنامج لعرضه هنا وتحويله إلى Shapefile.",
                "Export landmarks as KML/KMZ and open them in the app via Share/Open, or import a file from it to view here and convert to Shapefile.")));
        i.addView(Ui.button(a, S.t("⬆ استيراد ملف KML / KMZ", "⬆ Import KML / KMZ file"), true, new Runnable() {
            public void run() {
                a.pickImport();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 8, 0, 4));
        p.addView(i);

        LinearLayout e = Ui.card(a);
        e.addView(head(S.t("تصدير البيانات الحالية", "Export current data")));
        int n = 0;
        for (LayerData l : MainActivity.DATA) n += l.features.size();
        e.addView(note(S.t("المحمّل حالياً: ", "Currently loaded: ") + n + S.t(" عنصر في ", " features in ")
                + MainActivity.DATA.size() + S.t(" طبقة", " layers")));
        e.addView(Ui.button(a, "KML", false, new Runnable() {
            public void run() {
                a.export("kml");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, "KMZ", false, new Runnable() {
            public void run() {
                a.export("kmz");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, "Shapefile (ZIP)", true, new Runnable() {
            public void run() {
                a.export("shp");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, "GeoJSON", false, new Runnable() {
            public void run() {
                a.export("geojson");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, "GPX", false, new Runnable() {
            public void run() {
                a.export("gpx");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, "DXF (AutoCAD, UTM)", false, new Runnable() {
            public void run() {
                a.export("dxf");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, S.t("مسح البيانات المحمّلة", "Clear loaded data"), false, new Runnable() {
            public void run() {
                a.clearData();
                a.showPage("kml");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        p.addView(e);
        return p;
    }

    // ------------------------------------------------------------------ converter

    View converter() {
        LinearLayout p = col();
        LinearLayout in = Ui.card(a);
        in.addView(head(S.t("أدخل إحداثيات بأي صيغة", "Enter coordinates in any format")));
        in.addView(note(S.t("33.3152, 44.3661\n33°18'54.7\"N 44°21'58.0\"E\n38S 444000 3688000\n38SMB4400088000",
                "33.3152, 44.3661\n33°18'54.7\"N 44°21'58.0\"E\n38S 444000 3688000\n38SMB4400088000")));
        final EditText f = Ui.field(a, S.t("الصق أو اكتب هنا", "Paste or type here"), InputType.TYPE_CLASS_TEXT);
        f.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        f.setGravity(Gravity.START);
        in.addView(f, new LinearLayout.LayoutParams(-1, -2));
        final TextView status = Ui.text(a, "", 13, Theme.sub, false);
        status.setPadding(0, Ui.dp(a, 8), 0, 0);
        in.addView(status);
        LinearLayout br = Ui.row(a);
        br.addView(Ui.button(a, S.t("لصق", "Paste"), false, new Runnable() {
            public void run() {
                ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(a);
                    f.setText(t);
                }
            }
        }), Ui.lp(0, -2, 1f, a, 0, 8, 4, 0));
        br.addView(Ui.button(a, S.t("مسح", "Clear"), false, new Runnable() {
            public void run() {
                f.setText("");
            }
        }), Ui.lp(0, -2, 1f, a, 4, 8, 0, 0));
        in.addView(br);
        p.addView(in);

        final TextView[] vals = new TextView[4];
        final String[] names = {"DD", "DMS", "UTM", "MGRS"};
        LinearLayout out = Ui.card(a);
        out.addView(head(S.t("النتائج", "Results")));
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            out.addView(label(names[i] + (i == 0 ? S.t("  (خط الطول / دائرة العرض)", "  (lat / lon degrees)") : "")));
            LinearLayout r = Ui.row(a);
            r.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            vals[i] = Ui.text(a, "—", 15, Theme.text, true);
            vals[i].setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
            vals[i].setTextIsSelectable(true);
            r.addView(vals[i], new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(Ui.button(a, S.t("نسخ", "Copy"), false, new Runnable() {
                public void run() {
                    String s = vals[idx].getText().toString();
                    if (!s.equals("—")) a.copy(s);
                }
            }), new LinearLayout.LayoutParams(Ui.dp(a, 84), -2));
            out.addView(r);
        }
        final double[] cur = new double[2];
        final boolean[] ok = {false};
        LinearLayout ar = Ui.row(a);
        ar.addView(Ui.button(a, S.t("إظهار على الخريطة", "Show on map"), true, new Runnable() {
            public void run() {
                if (!ok[0]) {
                    a.toast(S.t("أدخل إحداثيات صحيحة أولاً", "Enter valid coordinates first"));
                    return;
                }
                a.setCenter(cur[0], cur[1]);
                a.showMap();
                a.map.getController().setZoom(15.0);
                a.map.getController().animateTo(new org.osmdroid.util.GeoPoint(cur[0], cur[1]));
            }
        }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        ar.addView(Ui.button(a, S.t("نسخ الكل", "Copy all"), false, new Runnable() {
            public void run() {
                if (!ok[0]) return;
                a.copy(vals[0].getText() + "\n" + vals[1].getText() + "\n" + vals[2].getText() + "\n" + vals[3].getText());
            }
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        out.addView(ar);
        p.addView(out);

        f.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                String t = e.toString();
                if (t.trim().isEmpty()) {
                    ok[0] = false;
                    status.setText("");
                    for (TextView v : vals) v.setText("—");
                    return;
                }
                try {
                    CoordFmt.Parsed ps = CoordFmt.parse(t);
                    cur[0] = ps.lat;
                    cur[1] = ps.lon;
                    ok[0] = true;
                    status.setTextColor(Theme.ok);
                    status.setText("✔ " + S.t("النوع المكتشف: ", "Detected: ") + ps.fmt);
                    vals[0].setText(CoordFmt.dd(ps.lat, ps.lon));
                    vals[1].setText(CoordFmt.dms(ps.lat, ps.lon));
                    vals[2].setText(CoordFmt.utm(ps.lat, ps.lon));
                    vals[3].setText(CoordFmt.format(CoordFmt.Fmt.MGRS, ps.lat, ps.lon));
                } catch (Exception ex) {
                    ok[0] = false;
                    status.setTextColor(Theme.danger);
                    status.setText("✖ " + S.t("صيغة غير مفهومة", "Unrecognised format"));
                    for (TextView v : vals) v.setText("—");
                }
            }
        });
        return p;
    }
}
