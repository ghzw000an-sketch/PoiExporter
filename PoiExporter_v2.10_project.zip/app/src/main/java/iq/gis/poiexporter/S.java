package iq.gis.poiexporter;

/** Tiny bilingual string helper: S.t("عربي", "English"). */
public final class S {
    public static boolean ar = true;

    private S() {
    }

    public static String t(String arabic, String english) {
        return ar ? arabic : english;
    }
}
