package iq.gis.poiexporter.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Parses Overpass JSON ("out center" or "out geom") into raw elements. */
public final class Overpass {
    public static final class Member {
        public String type = "", role = "";
        public double[] geom; // lon,lat interleaved
        public double lat = Double.NaN, lon = Double.NaN;
    }

    public static final class Elem {
        public String type = "";
        public long id;
        public Map<String, String> tags = Collections.emptyMap();
        public double lat = Double.NaN, lon = Double.NaN; // node position or center
        public double[] geom; // way geometry, lon,lat interleaved
        public List<Member> members;

        public String tag(String k) {
            String v = tags.get(k);
            return v == null ? "" : v;
        }

        public boolean hasCenter() {
            return !Double.isNaN(lat);
        }
    }

    /** Receives each element as soon as it is parsed. */
    public interface Sink {
        /** Return false to stop reading. */
        boolean accept(Elem e);
    }

    private Overpass() {}

    public static List<Elem> parse(InputStream in) throws IOException {
        final List<Elem> out = new ArrayList<>();
        parse(in, new Sink() {
            public boolean accept(Elem e) {
                out.add(e);
                return true;
            }
        });
        return out;
    }

    public static void parse(InputStream in, Sink sink) throws IOException {
        Reader r = new InputStreamReader(in, "UTF-8");
        JsonStream js = new JsonStream(r);
        js.beginObject();
        String remark = "";
        while (js.hasNext()) {
            String name = js.nextName();
            if (name.equals("elements")) {
                js.beginArray();
                while (js.hasNext()) {
                    Elem e = element(js);
                    if (!sink.accept(e)) return;
                }
            } else if (name.equals("remark") && js.peekIsString()) {
                remark = js.nextString();
            } else {
                js.skipValue();
            }
        }
        if (!remark.isEmpty() && remark.toLowerCase().contains("error")) throw new IOException(remark);
    }

    private static Elem element(JsonStream js) throws IOException {
        Elem e = new Elem();
        js.beginObject();
        while (js.hasNext()) {
            String n = js.nextName();
            switch (n) {
                case "type": e.type = js.nextString(); break;
                case "id": e.id = js.nextLong(); break;
                case "lat": e.lat = js.nextDouble(); break;
                case "lon": e.lon = js.nextDouble(); break;
                case "center": {
                    js.beginObject();
                    while (js.hasNext()) {
                        String k = js.nextName();
                        if (k.equals("lat")) e.lat = js.nextDouble();
                        else if (k.equals("lon")) e.lon = js.nextDouble();
                        else js.skipValue();
                    }
                    break;
                }
                case "tags": e.tags = js.nextStringMap(); break;
                case "geometry": e.geom = geometry(js); break;
                case "members": e.members = members(js); break;
                default: js.skipValue();
            }
        }
        return e;
    }

    private static double[] geometry(JsonStream js) throws IOException {
        double[] a = new double[64];
        int n = 0;
        js.beginArray();
        while (js.hasNext()) {
            if (js.peekIsNull()) {
                js.skipValue();
                continue;
            }
            double lat = Double.NaN, lon = Double.NaN;
            js.beginObject();
            while (js.hasNext()) {
                String k = js.nextName();
                if (k.equals("lat")) lat = js.nextDouble();
                else if (k.equals("lon")) lon = js.nextDouble();
                else js.skipValue();
            }
            if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
            if (n + 2 > a.length) a = java.util.Arrays.copyOf(a, a.length * 2);
            a[n++] = lon;
            a[n++] = lat;
        }
        return java.util.Arrays.copyOf(a, n);
    }

    private static List<Member> members(JsonStream js) throws IOException {
        List<Member> list = new ArrayList<>();
        js.beginArray();
        while (js.hasNext()) {
            Member m = new Member();
            js.beginObject();
            while (js.hasNext()) {
                String k = js.nextName();
                switch (k) {
                    case "type": m.type = js.nextString(); break;
                    case "role": m.role = js.nextString(); break;
                    case "lat": m.lat = js.nextDouble(); break;
                    case "lon": m.lon = js.nextDouble(); break;
                    case "geometry": m.geom = geometry(js); break;
                    default: js.skipValue();
                }
            }
            list.add(m);
        }
        return list;
    }
}
