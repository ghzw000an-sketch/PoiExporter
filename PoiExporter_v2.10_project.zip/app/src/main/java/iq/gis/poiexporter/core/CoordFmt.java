package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Formats and parses coordinates: decimal degrees, DMS, UTM and MGRS. */
public final class CoordFmt {
    public enum Fmt { DD, DMS, UTM, MGRS }

    public static final class Parsed {
        public final double lat, lon;
        public final Fmt fmt;

        Parsed(double lat, double lon, Fmt fmt) {
            this.lat = lat;
            this.lon = lon;
            this.fmt = fmt;
        }
    }

    private static final Pattern UTM = Pattern.compile(
            "^(\\d{1,2})\\s*([C-HJ-NP-X])?\\s+(?:E\\s*)?(\\d+(?:\\.\\d+)?)\\s*M?\\s+(?:N\\s*)?(\\d+(?:\\.\\d+)?)\\s*M?$");
    private static final Pattern TOKEN = Pattern.compile("([NSEW])|([+-]?\\d+(?:\\.\\d+)?|[+-]?\\.\\d+)");

    private CoordFmt() {}

    public static String format(Fmt f, double lat, double lon) {
        switch (f) {
            case DMS: return dms(lat, lon);
            case UTM: return utm(lat, lon);
            case MGRS:
                if (lat < -80 || lat > 84) return utm(lat, lon);
                return Mgrs.fromLatLon(lat, lon, 5);
            default: return dd(lat, lon);
        }
    }

    public static String dd(double lat, double lon) {
        return String.format(Locale.US, "%.7f, %.7f", lat, lon);
    }

    public static String utm(double lat, double lon) {
        Utm.Result u = Utm.fromLatLon(lat, lon);
        return String.format(Locale.US, "%s %.2f %.2f", u.zoneLabel(), u.easting, u.northing);
    }

    public static String dms(double lat, double lon) {
        return dms1(lat, 'N', 'S') + " " + dms1(lon, 'E', 'W');
    }

    private static String dms1(double v, char pos, char neg) {
        long cs = Math.round(Math.abs(v) * 3600 * 100);
        long deg = cs / 360000;
        long min = (cs % 360000) / 6000;
        double sec = (cs % 6000) / 100.0;
        return String.format(Locale.US, "%d°%02d'%05.2f\"%c", deg, min, sec, v < 0 ? neg : pos);
    }

    private static String normalize(String raw) {
        StringBuilder sb = new StringBuilder();
        for (char c : raw.trim().toCharArray()) {
            if (c >= '٠' && c <= '٩') sb.append((char) ('0' + (c - '٠')));
            else if (c >= '۰' && c <= '۹') sb.append((char) ('0' + (c - '۰')));
            else if (c == '٫') sb.append('.');
            else if (c == '،' || c == '؛') sb.append(',');
            else if (c == '−' || c == '–') sb.append('-');
            else if (c == '′' || c == '’' || c == '‘' || c == '`' || c == '´') sb.append('\'');
            else if (c == '″' || c == '”' || c == '“') sb.append('"');
            else sb.append(Character.toUpperCase(c));
        }
        return sb.toString();
    }

    /** Detects the format automatically. Throws IllegalArgumentException when nothing matches. */
    public static Parsed parse(String raw) {
        if (raw == null || raw.trim().isEmpty()) throw new IllegalArgumentException("empty");
        String t = normalize(raw);

        String compact = t.replaceAll("[\\s,;]+", "");
        if (Mgrs.looks(compact)) {
            double[] ll = Mgrs.toLatLon(compact);
            return new Parsed(ll[0], ll[1], Fmt.MGRS);
        }

        Matcher m = UTM.matcher(t.replace(',', ' ').replace(';', ' ').trim());
        if (m.matches()) {
            int zone = Integer.parseInt(m.group(1));
            double e = Double.parseDouble(m.group(3)), n = Double.parseDouble(m.group(4));
            String h = m.group(2);
            boolean north = h == null || "NPQRSTUVWX".contains(h); // latitude band: N..X north, C..M south
            if (zone >= 1 && zone <= 60 && e >= 100000 && e <= 900000 && n >= 0 && n <= 10000000) {
                double[] ll = Utm.toLatLon(zone, north, e, n);
                return new Parsed(ll[0], ll[1], Fmt.UTM);
            }
        }
        return parseDegrees(t);
    }

    private static final class Tok {
        boolean letter;
        char l;
        double v;
        boolean neg;
    }

    private static Parsed parseDegrees(String t) {
        String s = t.replaceAll("[°º'\":,;]", " ");
        List<Tok> toks = new ArrayList<>();
        Matcher m = TOKEN.matcher(s);
        int letters = 0;
        while (m.find()) {
            Tok k = new Tok();
            if (m.group(1) != null) {
                k.letter = true;
                k.l = m.group(1).charAt(0);
                letters++;
            } else {
                k.v = Double.parseDouble(m.group(2));
                k.neg = m.group(2).startsWith("-");
            }
            toks.add(k);
        }
        if (letters != 0 && letters != 2) throw new IllegalArgumentException("unrecognized coordinates");

        List<List<Tok>> chunks = new ArrayList<>();
        char[] chunkLetter = new char[2];
        if (letters == 0) {
            int n = toks.size();
            if (n != 2 && n != 4 && n != 6) throw new IllegalArgumentException("unrecognized coordinates");
            int per = n / 2;
            for (int c = 0; c < 2; c++) chunks.add(new ArrayList<>(toks.subList(c * per, (c + 1) * per)));
        } else if (toks.get(0).letter) {
            int li = 0;
            List<Tok> cur = null;
            for (Tok k : toks) {
                if (k.letter) {
                    chunkLetter[li++] = k.l;
                    cur = new ArrayList<>();
                    chunks.add(cur);
                } else {
                    cur.add(k);
                }
            }
        } else {
            int li = 0;
            List<Tok> cur = new ArrayList<>();
            for (Tok k : toks) {
                if (k.letter) {
                    chunkLetter[li++] = k.l;
                    chunks.add(cur);
                    cur = new ArrayList<>();
                } else {
                    cur.add(k);
                }
            }
            if (!cur.isEmpty()) throw new IllegalArgumentException("unrecognized coordinates");
        }
        if (chunks.size() != 2) throw new IllegalArgumentException("unrecognized coordinates");

        double[] val = new double[2];
        boolean dms = false;
        for (int c = 0; c < 2; c++) {
            List<Tok> ch = chunks.get(c);
            if (ch.isEmpty() || ch.size() > 3) throw new IllegalArgumentException("unrecognized coordinates");
            double d = Math.abs(ch.get(0).v);
            double mi = ch.size() > 1 ? ch.get(1).v : 0, se = ch.size() > 2 ? ch.get(2).v : 0;
            if (ch.size() > 1) dms = true;
            if (mi < 0 || mi >= 60 || se < 0 || se >= 60) throw new IllegalArgumentException("bad minutes or seconds");
            double v = d + mi / 60 + se / 3600;
            boolean neg;
            if (letters == 2) neg = chunkLetter[c] == 'S' || chunkLetter[c] == 'W';
            else neg = ch.get(0).neg;
            val[c] = neg ? -v : v;
        }
        double lat, lon;
        if (letters == 2) {
            boolean a0Lat = chunkLetter[0] == 'N' || chunkLetter[0] == 'S';
            boolean a1Lat = chunkLetter[1] == 'N' || chunkLetter[1] == 'S';
            if (a0Lat == a1Lat) throw new IllegalArgumentException("need one latitude and one longitude");
            lat = a0Lat ? val[0] : val[1];
            lon = a0Lat ? val[1] : val[0];
        } else {
            lat = val[0];
            lon = val[1];
        }
        if (Math.abs(lat) > 90 || Math.abs(lon) > 180) throw new IllegalArgumentException("out of range");
        return new Parsed(lat, lon, dms ? Fmt.DMS : Fmt.DD);
    }
}
