package iq.gis.poiexporter;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import iq.gis.poiexporter.core.Pipeline;

/** Overpass HTTP client with endpoint rotation and retries. */
public final class Net implements Pipeline.Fetcher {
    private static final String[] ENDPOINTS = {
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter"};
    private int start;

    @Override
    public InputStream post(String query) throws IOException {
        IOException last = null;
        byte[] body = ("data=" + URLEncoder.encode(query, "UTF-8")).getBytes("UTF-8");
        for (int attempt = 0; attempt < 5; attempt++) {
            String ep = ENDPOINTS[(start + attempt) % ENDPOINTS.length];
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(ep).openConnection();
                c.setConnectTimeout(20000);
                c.setReadTimeout(700000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("User-Agent", "PoiExporter/2.0 (Android; iq.gis.poiexporter)");
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                c.setFixedLengthStreamingMode(body.length);
                OutputStream os = c.getOutputStream();
                os.write(body);
                os.close();
                int code = c.getResponseCode();
                if (code == 200) {
                    start = (start + attempt) % ENDPOINTS.length;
                    return c.getInputStream();
                }
                last = new IOException("HTTP " + code + " @ " + ep);
                c.disconnect();
            } catch (IOException e) {
                last = e;
                if (c != null) c.disconnect();
            }
            try {
                Thread.sleep(800L * (attempt + 1));
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new IOException("interrupted");
            }
        }
        throw last != null ? last : new IOException("network");
    }
}
