package iq.gis.poiexporter.core;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;
import java.util.Locale;

/** Simple UTF-8 CSV (with BOM, opens correctly in Excel) of every feature with WGS84 and UTM columns. */
public final class CsvWriter {
    private CsvWriter() {
    }

    private static String q(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    public static void write(List<LayerData> layers, OutputStream os) throws IOException {
        Writer w = new OutputStreamWriter(os, "UTF-8");
        w.write('﻿');
        w.write("LAYER,NAME,TYPE,CATEGORY,NAHIYA,QADAA,GOVERNORAT,UTM_ZONE,X,Y,LON,LAT\r\n");
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                Utm.Result u = Utm.fromLatLon(f.lat, f.lon);
                w.write(q(l.label) + "," + q(f.name) + "," + q(f.type) + "," + q(f.category) + "," + q(f.nahiya) + ","
                        + q(f.qadaa) + "," + q(f.governorate) + "," + u.zoneLabel() + ","
                        + String.format(Locale.US, "%.2f,%.2f,%.7f,%.7f", u.easting, u.northing, f.lon, f.lat) + "\r\n");
            }
        }
        w.flush();
    }
}
