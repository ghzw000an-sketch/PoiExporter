package iq.gis.poiexporter.core;

/** Small geometry helpers. All coordinates are lon,lat degrees unless stated. */
public final class Geo {
    private static final double R = 6371008.8;

    private Geo() {}

    public static double haversine(double lat1, double lon1, double lat2, double lon2) {
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = p2 - p1, dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
    }

    /** {south, west, north, east} of a rectangle of w x h metres centred on the point. */
    public static double[] rectAround(double clat, double clon, double wM, double hM) {
        double dLat = Math.toDegrees(hM / 2 / R);
        double cos = Math.max(0.01, Math.cos(Math.toRadians(clat)));
        double dLon = Math.toDegrees(wM / 2 / (R * cos));
        return new double[]{clat - dLat, clon - dLon, clat + dLat, clon + dLon};
    }

    /** Closed ring lon,lat of a circle approximated by n segments. */
    public static double[] circleRing(double clat, double clon, double rM, int n) {
        double[] r = new double[(n + 1) * 2];
        double cos = Math.max(0.01, Math.cos(Math.toRadians(clat)));
        for (int i = 0; i <= n; i++) {
            double a = 2 * Math.PI * (i % n) / n;
            r[2 * i] = clon + Math.toDegrees(rM * Math.sin(a) / (R * cos));
            r[2 * i + 1] = clat + Math.toDegrees(rM * Math.cos(a) / R);
        }
        return r;
    }

    /** Signed area in square degrees; positive when counter-clockwise (x east, y north). */
    public static double signedArea(double[] ring) {
        double a = 0;
        int n = ring.length / 2;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            a += ring[2 * j] * ring[2 * i + 1] - ring[2 * i] * ring[2 * j + 1];
        }
        return a / 2;
    }

    public static double[] reversed(double[] ring) {
        int n = ring.length / 2;
        double[] r = new double[ring.length];
        for (int i = 0; i < n; i++) {
            r[2 * i] = ring[2 * (n - 1 - i)];
            r[2 * i + 1] = ring[2 * (n - 1 - i) + 1];
        }
        return r;
    }

    /** Ring with the requested orientation. */
    public static double[] oriented(double[] ring, boolean clockwise) {
        boolean isCcw = signedArea(ring) > 0;
        return (clockwise == !isCcw) ? ring : reversed(ring);
    }

    public static boolean pointInRing(double x, double y, double[] ring) {
        boolean in = false;
        int n = ring.length / 2;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            double xi = ring[2 * i], yi = ring[2 * i + 1], xj = ring[2 * j], yj = ring[2 * j + 1];
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) in = !in;
        }
        return in;
    }

    /** Even-odd test over all rings of a polygon feature, so holes are excluded. */
    public static boolean inPolygon(Feature f, double lon, double lat) {
        boolean in = false;
        for (double[] ring : f.parts) {
            int n = ring.length / 2;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                double xi = ring[2 * i], yi = ring[2 * i + 1], xj = ring[2 * j], yj = ring[2 * j + 1];
                if ((yi > lat) != (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) in = !in;
            }
        }
        return in;
    }

    public static double[] bbox(Feature f) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (double[] p : f.parts) {
            for (int i = 0; i + 1 < p.length; i += 2) {
                minX = Math.min(minX, p[i]);
                maxX = Math.max(maxX, p[i]);
                minY = Math.min(minY, p[i + 1]);
                maxY = Math.max(maxY, p[i + 1]);
            }
        }
        return new double[]{minX, minY, maxX, maxY};
    }

    public static double pathLength(double[] p) {
        double t = 0;
        for (int i = 1; i < p.length / 2; i++) t += haversine(p[2 * i - 1], p[2 * i - 2], p[2 * i + 1], p[2 * i]);
        return t;
    }

    /** Sets lat/lon: the point itself, the middle of a line, or a point inside the polygon. */
    public static void setRepresentative(Feature f) {
        if (f.parts.isEmpty()) return;
        if (f.geom == Feature.POINT) {
            double[] p = f.parts.get(0);
            f.lon = p[0];
            f.lat = p[1];
        } else if (f.geom == Feature.LINE) {
            double total = 0;
            for (double[] p : f.parts) total += pathLength(p);
            double half = total / 2, acc = 0;
            for (double[] p : f.parts) {
                int n = p.length / 2;
                for (int i = 1; i < n; i++) {
                    double seg = haversine(p[2 * i - 1], p[2 * i - 2], p[2 * i + 1], p[2 * i]);
                    if (acc + seg >= half && seg > 0) {
                        double t = (half - acc) / seg;
                        f.lon = p[2 * i - 2] + (p[2 * i] - p[2 * i - 2]) * t;
                        f.lat = p[2 * i - 1] + (p[2 * i + 1] - p[2 * i - 1]) * t;
                        return;
                    }
                    acc += seg;
                }
            }
            double[] p = f.parts.get(0);
            f.lon = p[0];
            f.lat = p[1];
        } else {
            int best = 0;
            double bestA = -1;
            for (int i = 0; i < f.parts.size(); i++) {
                if (f.isHole(i)) continue;
                double a = Math.abs(signedArea(f.parts.get(i)));
                if (a > bestA) {
                    bestA = a;
                    best = i;
                }
            }
            double[] r = f.parts.get(best);
            double cx = 0, cy = 0, a2 = 0;
            int n = r.length / 2;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                double cr = r[2 * j] * r[2 * i + 1] - r[2 * i] * r[2 * j + 1];
                a2 += cr;
                cx += (r[2 * j] + r[2 * i]) * cr;
                cy += (r[2 * j + 1] + r[2 * i + 1]) * cr;
            }
            if (Math.abs(a2) > 1e-18) {
                cx /= 3 * a2;
                cy /= 3 * a2;
                if (inPolygon(f, cx, cy)) {
                    f.lon = cx;
                    f.lat = cy;
                    return;
                }
            }
            // centroid outside (or hole): widest horizontal span through the middle of the bbox
            double[] bb = bbox(f);
            double bestW = -1, bx = r[0], by = r[1];
            for (int pass = 0; pass < 3; pass++) {
                double y = bb[1] + (bb[3] - bb[1]) * (0.5 + (pass - 1) * 0.2);
                java.util.ArrayList<Double> xs = new java.util.ArrayList<>();
                for (double[] ring : f.parts) {
                    int m = ring.length / 2;
                    for (int i = 0, j = m - 1; i < m; j = i++) {
                        double yi = ring[2 * i + 1], yj = ring[2 * j + 1];
                        if ((yi > y) != (yj > y)) {
                            double xi = ring[2 * i], xj = ring[2 * j];
                            xs.add((xj - xi) * (y - yi) / (yj - yi) + xi);
                        }
                    }
                }
                java.util.Collections.sort(xs);
                for (int k = 0; k + 1 < xs.size(); k += 2) {
                    double w = xs.get(k + 1) - xs.get(k);
                    if (w > bestW) {
                        bestW = w;
                        bx = (xs.get(k) + xs.get(k + 1)) / 2;
                        by = y;
                    }
                }
            }
            f.lon = bx;
            f.lat = by;
        }
    }

    /** Keeps at most max vertices (always the first and last) for drawing. */
    public static double[] decimate(double[] p, int max) {
        int n = p.length / 2;
        if (n <= max || max < 2) return p;
        double[] r = new double[max * 2];
        for (int i = 0; i < max; i++) {
            int src = (int) Math.round((double) i * (n - 1) / (max - 1));
            r[2 * i] = p[2 * src];
            r[2 * i + 1] = p[2 * src + 1];
        }
        return r;
    }

    public static void fillAdmin(Feature f, AdminIndex idx, int[] levels) {
        if (idx == null || idx.size() == 0) return;
        f.governorate = idx.find(levels[0], f.lat, f.lon);
        f.qadaa = idx.find(levels[1], f.lat, f.lon);
        f.nahiya = idx.find(levels[2], f.lat, f.lon);
    }
}
