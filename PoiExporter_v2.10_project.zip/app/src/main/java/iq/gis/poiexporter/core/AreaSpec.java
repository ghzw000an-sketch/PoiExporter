package iq.gis.poiexporter.core;

import java.util.Locale;

/** The area to download: a lat/lon rectangle or a circle. */
public final class AreaSpec {
    public final double south, west, north, east;
    public final boolean circle;
    public final double clat, clon, radius;
    /** Rotation in degrees clockwise from north (rectangles only) and the unrotated size. */
    public double rot, rw, rh;
    public double[] corners; // lon,lat x4 when rotated

    private AreaSpec(double s, double w, double n, double e, boolean circle, double clat, double clon, double r) {
        this.south = s;
        this.west = w;
        this.north = n;
        this.east = e;
        this.circle = circle;
        this.clat = clat;
        this.clon = clon;
        this.radius = r;
    }

    public static AreaSpec rect(double s, double w, double n, double e) {
        return new AreaSpec(s, w, n, e, false, (s + n) / 2, (w + e) / 2, 0);
    }

    public static AreaSpec circle(double lat, double lon, double radiusM) {
        double[] b = Geo.rectAround(lat, lon, radiusM * 2, radiusM * 2);
        return new AreaSpec(b[0], b[1], b[2], b[3], true, lat, lon, radiusM);
    }

    /** Rectangle of w x h metres around a centre. */
    public static AreaSpec centered(double lat, double lon, double wM, double hM) {
        double[] b = Geo.rectAround(lat, lon, wM, hM);
        return rect(b[0], b[1], b[2], b[3]);
    }

    /** Rectangle w x h metres, rotated clockwise by deg around its centre. */
    public static AreaSpec rotated(double lat, double lon, double wM, double hM, double deg) {
        double d = ((deg % 360) + 360) % 360;
        if (d < 1e-9) return centered(lat, lon, wM, hM);
        double mLat = 111320.0, mLon = 111320.0 * Math.max(0.05, Math.cos(Math.toRadians(lat)));
        double c = Math.cos(Math.toRadians(d)), s = Math.sin(Math.toRadians(d));
        double[][] q = {{-wM / 2, hM / 2}, {wM / 2, hM / 2}, {wM / 2, -hM / 2}, {-wM / 2, -hM / 2}};
        double[] co = new double[8];
        double mnLat = 90, mxLat = -90, mnLon = 180, mxLon = -180;
        for (int i = 0; i < 4; i++) {
            double x = q[i][0], y = q[i][1];
            double e = x * c + y * s, n = -x * s + y * c; // clockwise rotation
            double la = lat + n / mLat, lo = lon + e / mLon;
            co[2 * i] = lo;
            co[2 * i + 1] = la;
            mnLat = Math.min(mnLat, la);
            mxLat = Math.max(mxLat, la);
            mnLon = Math.min(mnLon, lo);
            mxLon = Math.max(mxLon, lo);
        }
        AreaSpec a = new AreaSpec(mnLat, mnLon, mxLat, mxLon, false, lat, lon, 0);
        a.rot = d;
        a.rw = wM;
        a.rh = hM;
        a.corners = co;
        return a;
    }

    public boolean isRotated() {
        return corners != null;
    }

    public double widthM() {
        if (corners != null) return rw;
        return circle ? radius * 2 : Geo.haversine(clat, west, clat, east);
    }

    public double heightM() {
        if (corners != null) return rh;
        return circle ? radius * 2 : Geo.haversine(south, clon, north, clon);
    }

    public double areaKm2() {
        if (circle) return Math.PI * radius * radius / 1e6;
        return widthM() * heightM() / 1e6;
    }

    /** Overpass area filter, such as (s,w,n,e) or (around:r,lat,lon). */
    public String overpass() {
        if (circle) return String.format(Locale.US, "(around:%.0f,%.6f,%.6f)", radius, clat, clon);
        if (corners != null) {
            StringBuilder sb = new StringBuilder("(poly:\"");
            for (int i = 0; i < 4; i++) sb.append(i > 0 ? " " : "").append(String.format(Locale.US, "%.6f %.6f", corners[2 * i + 1], corners[2 * i]));
            return sb.append("\")").toString();
        }
        return String.format(Locale.US, "(%.6f,%.6f,%.6f,%.6f)", south, west, north, east);
    }

    public boolean contains(double lat, double lon) {
        if (circle) return Geo.haversine(clat, clon, lat, lon) <= radius * 1.0005;
        if (corners != null) {
            double mLat = 111320.0, mLon = 111320.0 * Math.max(0.05, Math.cos(Math.toRadians(clat)));
            double e = (lon - clon) * mLon, n = (lat - clat) * mLat;
            double c = Math.cos(Math.toRadians(rot)), s = Math.sin(Math.toRadians(rot));
            double x = e * c - n * s, y = e * s + n * c; // inverse (counter-clockwise)
            return Math.abs(x) <= rw / 2 * 1.0005 && Math.abs(y) <= rh / 2 * 1.0005;
        }
        return lat >= south && lat <= north && lon >= west && lon <= east;
    }
}
