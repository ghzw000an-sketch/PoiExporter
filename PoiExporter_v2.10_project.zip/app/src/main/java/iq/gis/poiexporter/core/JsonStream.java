package iq.gis.poiexporter.core;

import java.io.IOException;
import java.io.Reader;

/** Small pull parser for JSON (like android.util.JsonReader) that works on any JVM and never builds a tree. */
public final class JsonStream {
    private final Reader in;
    private final char[] buf = new char[1 << 16];
    private int pos, lim;
    private boolean eof;

    public JsonStream(Reader in) {
        this.in = in;
    }

    private int read() throws IOException {
        if (pos >= lim) {
            if (eof) return -1;
            lim = in.read(buf, 0, buf.length);
            pos = 0;
            if (lim <= 0) {
                eof = true;
                lim = 0;
                return -1;
            }
        }
        return buf[pos++];
    }

    private int peekChar() throws IOException {
        int c = read();
        if (c != -1) pos--;
        return c;
    }

    private int skipWs() throws IOException {
        int c;
        while ((c = read()) != -1 && c <= ' ') { /* skip */ }
        return c;
    }

    /** Next significant char without consuming it, or -1. */
    private int peekSig() throws IOException {
        int c = skipWs();
        if (c != -1) pos--;
        return c;
    }

    private void expect(char ch) throws IOException {
        int c = skipWs();
        if (c != ch) throw new IOException("JSON: expected '" + ch + "' but got " + (c == -1 ? "end" : "'" + (char) c + "'"));
    }

    public void beginObject() throws IOException {
        expect('{');
    }

    public void beginArray() throws IOException {
        expect('[');
    }

    /** True when another member (object) or element (array) follows; consumes the closing bracket otherwise. */
    public boolean hasNext() throws IOException {
        int c = peekSig();
        if (c == ',') {
            read();
            c = peekSig();
        }
        if (c == '}' || c == ']') {
            read();
            return false;
        }
        if (c == -1) throw new IOException("JSON: unexpected end");
        return true;
    }

    public String nextName() throws IOException {
        String n = nextString();
        expect(':');
        return n;
    }

    public String nextString() throws IOException {
        int c = skipWs();
        if (c != '"') throw new IOException("JSON: expected string");
        StringBuilder sb = new StringBuilder();
        while (true) {
            c = read();
            if (c == -1) throw new IOException("JSON: unterminated string");
            if (c == '"') return sb.toString();
            if (c == '\\') {
                int e = read();
                switch (e) {
                    case 'n': sb.append('\n'); break;
                    case 't': sb.append('\t'); break;
                    case 'r': sb.append('\r'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'u': {
                        int v = 0;
                        for (int i = 0; i < 4; i++) {
                            int h = Character.digit(read(), 16);
                            if (h < 0) throw new IOException("JSON: bad unicode escape");
                            v = v * 16 + h;
                        }
                        sb.append((char) v);
                        break;
                    }
                    case -1: throw new IOException("JSON: unterminated string");
                    default: sb.append((char) e);
                }
            } else {
                sb.append((char) c);
            }
        }
    }

    public double nextDouble() throws IOException {
        int c = skipWs();
        long mant = 0;
        int digits = 0, scale = 0;
        boolean neg = false, frac = false;
        if (c == '-') {
            neg = true;
            c = read();
        } else if (c == '+') {
            c = read();
        }
        boolean any = false;
        double big = 0;
        boolean useBig = false;
        while (c >= '0' && c <= '9') {
            any = true;
            if (digits < 18) {
                mant = mant * 10 + (c - '0');
                if (mant != 0) digits++;
                if (frac) scale++;
            } else {
                if (!useBig) {
                    big = mant;
                    useBig = true;
                }
                if (!frac) big = big * 10 + (c - '0');
            }
            c = read();
            if (c == '.' && !frac) {
                frac = true;
                c = read();
            }
        }
        if (!any) throw new IOException("JSON: expected number");
        int exp = 0;
        if (c == 'e' || c == 'E') {
            boolean eneg = false;
            c = read();
            if (c == '-') {
                eneg = true;
                c = read();
            } else if (c == '+') {
                c = read();
            }
            while (c >= '0' && c <= '9') {
                exp = exp * 10 + (c - '0');
                c = read();
            }
            if (eneg) exp = -exp;
        }
        if (c != -1) pos--;
        double v = useBig ? big : (double) mant;
        int e10 = exp - scale;
        if (e10 != 0) v = e10 < 0 ? v / Math.pow(10, -e10) : v * Math.pow(10, e10);
        return neg ? -v : v;
    }

    public long nextLong() throws IOException {
        return (long) nextDouble();
    }

    public boolean nextBoolean() throws IOException {
        int c = skipWs();
        if (c == 't') {
            skipLiteral("rue");
            return true;
        }
        if (c == 'f') {
            skipLiteral("alse");
            return false;
        }
        throw new IOException("JSON: expected boolean");
    }

    private void skipLiteral(String rest) throws IOException {
        for (int i = 0; i < rest.length(); i++) if (read() != rest.charAt(i)) throw new IOException("JSON: bad literal");
    }

    /** Skips the next value of any kind. */
    public void skipValue() throws IOException {
        int c = peekSig();
        if (c == '{') {
            beginObject();
            while (hasNext()) {
                nextName();
                skipValue();
            }
        } else if (c == '[') {
            beginArray();
            while (hasNext()) skipValue();
        } else if (c == '"') {
            nextString();
        } else if (c == 't' || c == 'f') {
            nextBoolean();
        } else if (c == 'n') {
            read();
            skipLiteral("ull");
        } else {
            nextDouble();
        }
    }

    public boolean peekIsObject() throws IOException {
        return peekSig() == '{';
    }

    public boolean peekIsNull() throws IOException {
        return peekSig() == 'n';
    }

    public boolean peekIsString() throws IOException {
        return peekSig() == '"';
    }

    public boolean peekIsNumber() throws IOException {
        int c = peekSig();
        return c == '-' || (c >= '0' && c <= '9');
    }

    /** Reads a flat object of string values; non-string values are read as text. */
    public java.util.Map<String, String> nextStringMap() throws IOException {
        java.util.Map<String, String> m = new java.util.LinkedHashMap<>();
        beginObject();
        while (hasNext()) {
            String k = nextName();
            if (peekIsString()) m.put(k, nextString());
            else if (peekIsNumber()) m.put(k, trim(nextDouble()));
            else skipValue();
        }
        return m;
    }

    private static String trim(double d) {
        return d == Math.rint(d) && Math.abs(d) < 1e15 ? Long.toString((long) d) : Double.toString(d);
    }
}
