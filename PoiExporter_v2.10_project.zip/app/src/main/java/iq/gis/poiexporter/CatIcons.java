package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

import java.util.Locale;

/** Small category badges drawn in code (no image files): a coloured circle with a white symbol. */
public final class CatIcons {
    private CatIcons() {
    }

    private static boolean in(String v, String... set) {
        for (String s : set) if (s.equals(v)) return true;
        return false;
    }

    private static boolean has(String text, String... words) {
        for (String w : words) if (text.contains(w)) return true;
        return false;
    }

    /** Symbol name for an OSM value and the category label. */
    public static String kind(String type, String category) {
        String t = type == null ? "" : type.toLowerCase(Locale.US);
        String c = category == null ? "" : category.toLowerCase(Locale.US);
        if (in(t, "hospital", "clinic", "doctors", "dentist", "pharmacy", "veterinary") || has(c, "مستشف", "صيدل", "عياد", "hospital", "clinic", "pharm")) return "health";
        if (in(t, "school", "kindergarten", "university", "college", "library") || has(c, "مدرس", "جامع", "كلي", "school", "universit", "college")) return "edu";
        if (in(t, "restaurant", "cafe", "fast_food", "bar", "pub", "food_court", "ice_cream") || has(c, "مطعم", "مقه", "restaurant", "cafe")) return "food";
        if (in(t, "fuel", "car_wash", "charging_station") || has(c, "وقود", "fuel")) return "fuel";
        if (in(t, "bank", "atm", "bureau_de_change") || has(c, "بنك", "مصرف", "bank")) return "bank";
        if (in(t, "place_of_worship", "mosque", "church") || has(c, "جامع", "مسجد", "عبادة", "worship", "mosque")) return "worship";
        if (in(t, "bus_station", "station", "halt", "taxi", "aerodrome", "terminal") || has(c, "نقل", "محطة", "transport", "station")) return "transport";
        if (in(t, "stadium", "pitch", "sports_centre", "track", "swimming_pool", "golf_course") || has(c, "ملعب", "رياض", "sport", "stadium")) return "sport";
        if (in(t, "hotel", "guest_house", "motel", "attraction", "museum", "camp_site") || has(c, "فندق", "سياح", "tourism", "hotel")) return "tourism";
        if (in(t, "works", "industrial", "factory", "warehouse") || has(c, "مصنع", "معمل", "صناع", "factory", "industr")) return "industry";
        if (in(t, "police", "fire_station", "townhall", "courthouse", "prison", "embassy") || has(c, "شرط", "بلدية", "حكوم", "police", "government")) return "gov";
        if (in(t, "supermarket", "convenience", "mall", "bakery", "marketplace", "department_store") || has(c, "سوق", "سوبر", "محل", "متجر", "market", "shop", "store")) return "shop";
        if (in(t, "motorway", "trunk", "primary", "secondary", "tertiary", "residential", "service", "track", "path") || has(c, "طريق", "شارع", "road", "street")) return "road";
        if (in(t, "river", "stream", "canal", "lake", "water", "reservoir", "dam") || has(c, "نهر", "بحيرة", "سد", "river", "lake", "dam", "water")) return "water";
        if (in(t, "city", "town", "village", "suburb", "neighbourhood", "quarter", "hamlet", "administrative") || has(c, "ناحية", "قضاء", "محافظ", "حي", "place", "admin")) return "place";
        return "dot";
    }

    public static int color(String kind) {
        switch (kind) {
            case "health": return 0xFFD32F2F;
            case "edu": return 0xFF7B1FA2;
            case "food": return 0xFFEF6C00;
            case "shop": return 0xFF00838F;
            case "fuel": return 0xFFE64A19;
            case "bank": return 0xFF3949AB;
            case "worship": return 0xFF5E35B1;
            case "transport": return 0xFF1976D2;
            case "sport": return 0xFF558B2F;
            case "tourism": return 0xFFC2185B;
            case "industry": return 0xFF6D4C41;
            case "gov": return 0xFF455A64;
            case "road": return 0xFF757575;
            case "water": return 0xFF0288D1;
            case "place": return 0xFFC62828;
            default: return 0xFF607D8B;
        }
    }

    /** Draws the badge centred at (cx, cy) with radius r. */
    public static void draw(Canvas cv, String kind, float cx, float cy, float r) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color(kind));
        cv.drawCircle(cx, cy, r, p);
        float u = r / 12f; // symbol grid: -12..12
        p.setColor(0xFFFFFFFF);
        Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
        st.setStyle(Paint.Style.STROKE);
        st.setColor(0xFFFFFFFF);
        st.setStrokeWidth(Math.max(1f, 1.6f * u));
        st.setStrokeCap(Paint.Cap.ROUND);
        st.setStrokeJoin(Paint.Join.ROUND);
        Path path = new Path();
        switch (kind) {
            case "health":
                cv.drawRect(cx - 2.2f * u, cy - 7 * u, cx + 2.2f * u, cy + 7 * u, p);
                cv.drawRect(cx - 7 * u, cy - 2.2f * u, cx + 7 * u, cy + 2.2f * u, p);
                break;
            case "edu":
                cv.drawRect(cx - 7 * u, cy - 5 * u, cx + 7 * u, cy + 5 * u, st);
                cv.drawLine(cx, cy - 5 * u, cx, cy + 5 * u, st);
                break;
            case "food":
                path.moveTo(cx - 5 * u, cy - 4 * u);
                path.lineTo(cx + 3 * u, cy - 4 * u);
                path.lineTo(cx + 2 * u, cy + 6 * u);
                path.lineTo(cx - 4 * u, cy + 6 * u);
                path.close();
                cv.drawPath(path, p);
                cv.drawArc(new RectF(cx + 1.5f * u, cy - 2 * u, cx + 7 * u, cy + 3 * u), -90, 180, false, st);
                break;
            case "shop":
                cv.drawRect(cx - 6 * u, cy - 2 * u, cx + 6 * u, cy + 7 * u, p);
                cv.drawArc(new RectF(cx - 3.5f * u, cy - 7 * u, cx + 3.5f * u, cy + 1 * u), 180, 180, false, st);
                break;
            case "fuel":
                path.moveTo(cx, cy - 8 * u);
                path.cubicTo(cx + 8 * u, cy + 1 * u, cx + 6 * u, cy + 8 * u, cx, cy + 8 * u);
                path.cubicTo(cx - 6 * u, cy + 8 * u, cx - 8 * u, cy + 1 * u, cx, cy - 8 * u);
                cv.drawPath(path, p);
                break;
            case "bank":
                path.moveTo(cx - 8 * u, cy - 3 * u);
                path.lineTo(cx, cy - 8 * u);
                path.lineTo(cx + 8 * u, cy - 3 * u);
                path.close();
                cv.drawPath(path, p);
                for (int i = -1; i <= 1; i++) cv.drawRect(cx + i * 5 * u - 1.3f * u, cy - 1 * u, cx + i * 5 * u + 1.3f * u, cy + 5 * u, p);
                cv.drawRect(cx - 8 * u, cy + 6 * u, cx + 8 * u, cy + 8 * u, p);
                break;
            case "worship":
                cv.drawArc(new RectF(cx - 6 * u, cy - 7 * u, cx + 6 * u, cy + 5 * u), 180, 180, true, p);
                cv.drawRect(cx - 6 * u, cy - 1 * u, cx + 6 * u, cy + 7 * u, p);
                cv.drawLine(cx, cy - 11 * u, cx, cy - 6 * u, st);
                break;
            case "transport":
                cv.drawRoundRect(new RectF(cx - 7 * u, cy - 7 * u, cx + 7 * u, cy + 5 * u), 2 * u, 2 * u, p);
                cv.drawCircle(cx - 4 * u, cy + 7 * u, 1.8f * u, p);
                cv.drawCircle(cx + 4 * u, cy + 7 * u, 1.8f * u, p);
                break;
            case "sport":
                cv.drawCircle(cx, cy, 7 * u, st);
                cv.drawLine(cx - 7 * u, cy, cx + 7 * u, cy, st);
                cv.drawArc(new RectF(cx - 3 * u, cy - 7 * u, cx + 3 * u, cy + 7 * u), 0, 360, false, st);
                break;
            case "tourism":
                cv.drawRoundRect(new RectF(cx - 8 * u, cy - 4 * u, cx + 8 * u, cy + 7 * u), 2 * u, 2 * u, p);
                cv.drawRect(cx - 3 * u, cy - 7 * u, cx + 3 * u, cy - 4 * u, p);
                p.setColor(color(kind));
                cv.drawCircle(cx, cy + 1.5f * u, 3 * u, p);
                break;
            case "industry":
                path.moveTo(cx - 8 * u, cy + 7 * u);
                path.lineTo(cx - 8 * u, cy - 1 * u);
                path.lineTo(cx - 3 * u, cy + 2 * u);
                path.lineTo(cx - 3 * u, cy - 1 * u);
                path.lineTo(cx + 2 * u, cy + 2 * u);
                path.lineTo(cx + 2 * u, cy - 7 * u);
                path.lineTo(cx + 6 * u, cy - 7 * u);
                path.lineTo(cx + 6 * u, cy + 7 * u);
                path.close();
                cv.drawPath(path, p);
                break;
            case "gov":
                cv.drawLine(cx - 5 * u, cy - 8 * u, cx - 5 * u, cy + 8 * u, st);
                cv.drawRect(cx - 5 * u, cy - 8 * u, cx + 7 * u, cy + 1 * u, p);
                break;
            case "road":
                path.moveTo(cx - 6 * u, cy + 8 * u);
                path.lineTo(cx - 2 * u, cy - 8 * u);
                path.moveTo(cx + 6 * u, cy + 8 * u);
                path.lineTo(cx + 2 * u, cy - 8 * u);
                cv.drawPath(path, st);
                cv.drawLine(cx, cy - 6 * u, cx, cy - 3 * u, st);
                cv.drawLine(cx, cy + 1 * u, cx, cy + 4 * u, st);
                break;
            case "water":
                path.moveTo(cx - 8 * u, cy - 1 * u);
                path.quadTo(cx - 4 * u, cy - 6 * u, cx, cy - 1 * u);
                path.quadTo(cx + 4 * u, cy + 4 * u, cx + 8 * u, cy - 1 * u);
                cv.drawPath(path, st);
                path.reset();
                path.moveTo(cx - 8 * u, cy + 5 * u);
                path.quadTo(cx - 4 * u, cy, cx, cy + 5 * u);
                path.quadTo(cx + 4 * u, cy + 10 * u, cx + 8 * u, cy + 5 * u);
                cv.drawPath(path, st);
                break;
            case "place":
                cv.drawCircle(cx, cy, 7 * u, st);
                cv.drawCircle(cx, cy, 2.4f * u, p);
                break;
            default:
                cv.drawCircle(cx, cy, 3.5f * u, p);
        }
    }

    /** A square drawable of the given pixel size showing the badge for this feature. */
    public static Drawable drawable(final String type, final String category, final int px) {
        final String k = kind(type, category);
        return new Drawable() {
            @Override
            public void draw(Canvas c) {
                android.graphics.Rect b = getBounds();
                CatIcons.draw(c, k, b.exactCenterX(), b.exactCenterY(), Math.min(b.width(), b.height()) / 2f);
            }

            @Override
            public void setAlpha(int alpha) {
            }

            @Override
            public void setColorFilter(ColorFilter cf) {
            }

            @Override
            public int getOpacity() {
                return PixelFormat.TRANSLUCENT;
            }

            @Override
            public int getIntrinsicWidth() {
                return px;
            }

            @Override
            public int getIntrinsicHeight() {
                return px;
            }
        };
    }
}
