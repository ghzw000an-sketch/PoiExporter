package iq.gis.poiexporter.core;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Reads map-source definition files (.aqx, XML) that the user already has, and turns every source
 * whose tile address can be expressed as a plain XYZ link into an {@link Entry}.
 * Sources that need private tokens, quadkeys, bounding boxes or other custom parameters are
 * reported in {@link Result#skipped} instead of being guessed.
 */
public final class AqxParser {
    public static final class Entry {
        public String id = "", name = "", url = "";
        public boolean overlay;
        /** The file says the provider does not allow downloading tiles in bulk. */
        public boolean noBulk;
        public int minZ = 0, maxZ = 19;
    }

    public static final class Result {
        public String title = "";
        public final List<Entry> entries = new ArrayList<>();
        public final List<String> skipped = new ArrayList<>();
    }

    private AqxParser() {
    }

    private static String text(Element e, String tag) {
        NodeList l = e.getElementsByTagName(tag);
        for (int i = 0; i < l.getLength(); i++) {
            Node n = l.item(i);
            if (n.getParentNode() == e) return n.getTextContent().trim();
        }
        return "";
    }

    private static List<Element> children(Element e, String tag) {
        List<Element> out = new ArrayList<>();
        NodeList l = e.getChildNodes();
        for (int i = 0; i < l.getLength(); i++) {
            Node n = l.item(i);
            if (n instanceof Element && ((Element) n).getTagName().equals(tag)) out.add((Element) n);
        }
        return out;
    }

    /** "1-9" or "1,2,3" or "4" -> {min,max}. */
    static int[] zoomRange(String z) {
        int min = 99, max = -1;
        for (String part : z.split(",")) {
            part = part.trim();
            if (part.isEmpty()) continue;
            int dash = part.indexOf('-', 1);
            try {
                if (dash > 0) {
                    min = Math.min(min, Integer.parseInt(part.substring(0, dash).trim()));
                    max = Math.max(max, Integer.parseInt(part.substring(dash + 1).trim()));
                } else {
                    int v = Integer.parseInt(part);
                    min = Math.min(min, v);
                    max = Math.max(max, v);
                }
            } catch (NumberFormatException ignored) {
                // ignore a malformed piece
            }
        }
        return max < 0 ? new int[]{0, 19} : new int[]{min, max};
    }

    /** Converts one server template to a plain XYZ link, or returns null if it needs anything else. */
    static String toXyz(String t) {
        String u = t.replace("{$http}", "https").replace("{$z}", "{z}").replace("{$x}", "{x}").replace("{$y}", "{y}");
        if (u.contains("{$")) return null;
        String low = u.toLowerCase();
        if (!(low.startsWith("https://") || low.startsWith("http://"))) return null;
        // servers that belong to the other app's vendor are meant for that app only
        if (low.contains("psyberia.org")) return null;
        return u;
    }

    private static boolean isOverlay(String type, String name) {
        String t = type.toLowerCase();
        if (t.equals("contours") || t.equals("hillshade") || t.equals("other")) return true;
        String n = name.toLowerCase();
        return n.endsWith("layer") || n.contains(" layer");
    }

    public static Result parse(InputStream in) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        // never resolve external entities from a file the user picked
        try {
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        } catch (Exception ignored) {
            // parser without that feature
        }
        f.setExpandEntityReferences(false);
        DocumentBuilder b = f.newDocumentBuilder();
        Document d = b.parse(in);
        Element root = d.getDocumentElement();
        Result r = new Result();
        r.title = text(root, "name");
        NodeList srcs = root.getElementsByTagName("source");
        for (int i = 0; i < srcs.getLength(); i++) {
            Element s = (Element) srcs.item(i);
            String id = s.getAttribute("id"), type = s.getAttribute("type");
            String name = text(s, "name");
            if (name.isEmpty()) name = id;
            boolean noBulk = "false".equalsIgnoreCase(s.getAttribute("allow-bulk-download"))
                    || "false".equalsIgnoreCase(s.getAttribute("allow-export"));
            List<Element> zls = children(s, "zoom-levels");
            int made = 0;
            for (Element zl : zls) {
                String url = null;
                for (Element sv : children(zl, "server")) {
                    url = toXyz(sv.getTextContent().trim());
                    if (url != null) break;
                }
                if (url == null) continue;
                int[] zr = zoomRange(zl.getAttribute("z"));
                Entry e = new Entry();
                e.id = id;
                e.name = name + (zls.size() > 1 ? " (" + zr[0] + "-" + zr[1] + ")" : "");
                e.url = url;
                e.overlay = isOverlay(type, name);
                e.noBulk = noBulk;
                e.minZ = zr[0];
                e.maxZ = zr[1];
                r.entries.add(e);
                made++;
            }
            if (made == 0) r.skipped.add(name);
        }
        return r;
    }
}
