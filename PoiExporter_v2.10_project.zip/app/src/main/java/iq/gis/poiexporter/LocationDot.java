package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

/** Blue dot with accuracy circle for the GPS position. */
public final class LocationDot extends Overlay {
    private boolean has;
    private double lat, lon;
    private float acc;
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG),
            area = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    public LocationDot(float density) {
        d = density;
        dot.setColor(0xFF1C7ED6);
        ring.setColor(0xFFFFFFFF);
        area.setColor(0x221C7ED6);
    }

    public void set(double lat, double lon, float acc) {
        this.lat = lat;
        this.lon = lon;
        this.acc = acc;
        has = true;
    }

    public void clear() {
        has = false;
    }

    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (shadow || !has) return;
        Point p = new Point();
        map.getProjection().toPixels(new GeoPoint(lat, lon), p);
        float r = map.getProjection().metersToPixels(acc);
        if (r > 6 * d) c.drawCircle(p.x, p.y, r, area);
        c.drawCircle(p.x, p.y, 9 * d, ring);
        c.drawCircle(p.x, p.y, 6.5f * d, dot);
    }
}
