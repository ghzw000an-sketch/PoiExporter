package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.view.MotionEvent;

import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.Projection;
import org.osmdroid.views.overlay.Overlay;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Geo;

/**
 * Draws the selected area. Drag inside to move, drag a corner to resize, drag the top handle to rotate
 * (0-360 degrees), long-press to re-centre.
 */
public final class AreaOverlay extends Overlay {
    public interface Edited {
        /** circle: wM = hM = radius. rot = degrees clockwise from north. */
        void changed(double clat, double clon, double wM, double hM, boolean circle, double rot);
    }

    public interface Moved {
        void to(double lat, double lon);
    }

    private AreaSpec area;
    private Moved moved;
    private Edited edited;
    private TapOverlay.Tapped tapCb;
    private boolean editable = true;
    private boolean visible = true;
    private boolean squareMode;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG), casing = new Paint(Paint.ANTI_ALIAS_FLAG),
            fill = new Paint(Paint.ANTI_ALIAS_FLAG), cross = new Paint(Paint.ANTI_ALIAS_FLAG),
            handle = new Paint(Paint.ANTI_ALIAS_FLAG), handleRing = new Paint(Paint.ANTI_ALIAS_FLAG),
            rotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Point tmp = new Point();
    private final GeoPoint gp = new GeoPoint(0.0, 0.0);
    private final float density;

    // drag state
    private int mode; // 0 none, 1 move, 2 resize corner, 3 resize circle, 4 rotate
    private double fixLat, fixLon;
    private double grabDLat, grabDLon;
    private float downX, downY;
    private boolean dragged;
    private float[] hx = new float[4], hy = new float[4];
    private float rx, ry; // rotation handle
    private boolean hasRot;

    public AreaOverlay(float density) {
        this.density = density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f * density);
        stroke.setColor(0xFFE03131);
        casing.setStyle(Paint.Style.STROKE);
        casing.setStrokeWidth(6f * density);
        casing.setColor(0xCCFFFFFF);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x2EE03131);
        cross.setStyle(Paint.Style.STROKE);
        cross.setStrokeWidth(2f * density);
        cross.setColor(0xFFE03131);
        handle.setStyle(Paint.Style.FILL);
        handle.setColor(0xFFE03131);
        handleRing.setStyle(Paint.Style.STROKE);
        handleRing.setStrokeWidth(2.5f * density);
        handleRing.setColor(0xFFFFFFFF);
        rotPaint.setStyle(Paint.Style.FILL);
        rotPaint.setColor(0xFF1C7ED6);
    }

    public void set(AreaSpec s) {
        area = s;
    }

    public void onMoved(Moved m) {
        moved = m;
    }

    public void onEdited(Edited e) {
        edited = e;
    }

    public void setTapCallback(TapOverlay.Tapped t) {
        tapCb = t;
    }

    public void setEditable(boolean b) {
        editable = b;
    }

    public void setVisible2(boolean v) {
        visible = v;
    }

    public boolean isVisible2() {
        return visible;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setSquare(boolean sq) {
        squareMode = sq;
    }

    private double[] cornersGeo() { // lon,lat x4: NW, NE, SE, SW
        if (area.isRotated()) return area.corners;
        return new double[]{area.west, area.north, area.east, area.north, area.east, area.south, area.west, area.south};
    }

    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (shadow || area == null || !visible) return;
        Projection pj = map.getProjection();
        Path path = new Path();
        hasRot = false;
        if (area.circle) {
            double[] ring = Geo.circleRing(area.clat, area.clon, area.radius, 72);
            for (int i = 0; i < ring.length / 2; i++) {
                gp.setCoords(ring[2 * i + 1], ring[2 * i]);
                pj.toPixels(gp, tmp);
                if (i == 0) path.moveTo(tmp.x, tmp.y);
                else path.lineTo(tmp.x, tmp.y);
            }
            gp.setCoords(area.clat, area.east);
            pj.toPixels(gp, tmp);
            hx[0] = tmp.x;
            hy[0] = tmp.y;
        } else {
            double[] co = cornersGeo();
            for (int i = 0; i < 4; i++) {
                gp.setCoords(co[2 * i + 1], co[2 * i]);
                pj.toPixels(gp, tmp);
                hx[i] = tmp.x;
                hy[i] = tmp.y;
                if (i == 0) path.moveTo(tmp.x, tmp.y);
                else path.lineTo(tmp.x, tmp.y);
            }
        }
        path.close();
        c.drawPath(path, fill);
        c.drawPath(path, casing);
        c.drawPath(path, stroke);
        gp.setCoords(area.clat, area.clon);
        pj.toPixels(gp, tmp);
        float cx = tmp.x, cy = tmp.y;
        float r = 8 * density;
        c.drawLine(cx - r, cy, cx + r, cy, cross);
        c.drawLine(cx, cy - r, cx, cy + r, cross);
        if (editable) {
            int n = area.circle ? 1 : 4;
            for (int i = 0; i < n; i++) {
                c.drawCircle(hx[i], hy[i], 9 * density, handle);
                c.drawCircle(hx[i], hy[i], 9 * density, handleRing);
            }
            if (!area.circle) {
                // rotation handle beyond the middle of the top edge
                float mx = (hx[0] + hx[1]) / 2, my = (hy[0] + hy[1]) / 2;
                float dx = mx - cx, dy = my - cy;
                float len = (float) Math.max(1, Math.hypot(dx, dy));
                rx = mx + dx / len * 34 * density;
                ry = my + dy / len * 34 * density;
                hasRot = true;
                c.drawLine(mx, my, rx, ry, stroke);
                c.drawCircle(rx, ry, 12 * density, rotPaint);
                c.drawCircle(rx, ry, 12 * density, handleRing);
                Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
                t.setColor(0xFFFFFFFF);
                t.setTextSize(15 * density);
                t.setTextAlign(Paint.Align.CENTER);
                c.drawText("↻", rx, ry + 5 * density, t);
            }
        }
    }

    private boolean inside(MapView map, float x, float y) {
        IGeoPoint g = map.getProjection().fromPixels((int) x, (int) y);
        if (area.circle) return Geo.haversine(area.clat, area.clon, g.getLatitude(), g.getLongitude()) <= area.radius;
        if (area.isRotated()) return area.contains(g.getLatitude(), g.getLongitude());
        return g.getLatitude() >= area.south && g.getLatitude() <= area.north && g.getLongitude() >= area.west
                && g.getLongitude() <= area.east;
    }

    private static double mLon(double lat) {
        return 111320.0 * Math.max(0.05, Math.cos(Math.toRadians(lat)));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e, MapView map) {
        if (area == null || edited == null || !visible) return false;
        if (e.getPointerCount() > 1) {
            mode = 0;
            return false;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                mode = 0;
                dragged = false;
                downX = e.getX();
                downY = e.getY();
                if (editable) {
                    float tol = 30 * density;
                    if (hasRot && !area.circle && Math.hypot(rx - e.getX(), ry - e.getY()) <= tol) {
                        mode = 4;
                    } else {
                        int n = area.circle ? 1 : 4;
                        for (int i = 0; i < n; i++) {
                            if (Math.hypot(hx[i] - e.getX(), hy[i] - e.getY()) <= tol) {
                                if (area.circle) mode = 3;
                                else {
                                    mode = 2;
                                    double[] co = cornersGeo();
                                    int o = (i + 2) % 4;
                                    fixLon = co[2 * o];
                                    fixLat = co[2 * o + 1];
                                }
                                break;
                            }
                        }
                    }
                }
                if (mode == 0 && inside(map, e.getX(), e.getY())) {
                    mode = 1;
                    IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
                    grabDLat = area.clat - g.getLatitude();
                    grabDLon = area.clon - g.getLongitude();
                }
                return mode != 0;
            }
            case MotionEvent.ACTION_MOVE: {
                if (mode == 0) return false;
                if (Math.hypot(e.getX() - downX, e.getY() - downY) > 10 * density) dragged = true;
                if (mode == 1 && !dragged) return true;
                if (!editable) return true;
                IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
                double lat = g.getLatitude(), lon = g.getLongitude();
                double w = area.circle ? area.radius : area.widthM(), h = area.circle ? area.radius : area.heightM();
                if (mode == 1) {
                    edited.changed(lat + grabDLat, lon + grabDLon, w, h, area.circle, area.rot);
                } else if (mode == 3) {
                    double rad = Math.max(10, Geo.haversine(area.clat, area.clon, lat, lon));
                    edited.changed(area.clat, area.clon, rad, rad, true, 0);
                } else if (mode == 4) {
                    double de = (lon - area.clon) * mLon(area.clat), dn = (lat - area.clat) * 111320.0;
                    double deg = Math.toDegrees(Math.atan2(de, dn));
                    deg = ((deg % 360) + 360) % 360;
                    edited.changed(area.clat, area.clon, w, h, false, deg);
                } else {
                    double rot = area.rot;
                    double ml = mLon(fixLat);
                    double ve = (lon - fixLon) * ml, vn = (lat - fixLat) * 111320.0;
                    double cs = Math.cos(Math.toRadians(rot)), sn = Math.sin(Math.toRadians(rot));
                    double x = ve * cs - vn * sn, y = ve * sn + vn * cs; // into the rectangle's own axes
                    if (squareMode) {
                        double side = Math.max(Math.abs(x), Math.abs(y));
                        x = Math.signum(x == 0 ? 1 : x) * side;
                        y = Math.signum(y == 0 ? 1 : y) * side;
                        ve = x * cs + y * sn;
                        vn = -x * sn + y * cs;
                    }
                    double nw = Math.max(10, Math.abs(x)), nh = Math.max(10, Math.abs(y));
                    double clat = fixLat + vn / 2 / 111320.0, clon = fixLon + ve / 2 / ml;
                    edited.changed(clat, clon, nw, nh, false, rot);
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                boolean was = mode != 0;
                boolean tap = mode == 1 && !dragged && tapCb != null && e.getActionMasked() == MotionEvent.ACTION_UP;
                mode = 0;
                if (tap) {
                    IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
                    tapCb.at(g.getLatitude(), g.getLongitude());
                    return true;
                }
                return was;
            }
            default:
                return mode != 0;
        }
    }

    @Override
    public boolean onLongPress(MotionEvent e, MapView map) {
        if (moved == null) return false;
        IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
        moved.to(g.getLatitude(), g.getLongitude());
        return true;
    }
}
