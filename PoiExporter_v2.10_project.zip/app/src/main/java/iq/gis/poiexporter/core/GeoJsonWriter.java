package iq.gis.poiexporter.core;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** GeoJSON (RFC 7946, WGS84) with the same attribute columns as the Shapefile export. */
public final class GeoJsonWriter {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private GeoJsonWriter() {
    }

    static String esc(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        return b.toString();
    }

    private static void pos(StringBuilder b, double lon, double lat) {
        b.append(String.format(Locale.US, "[%.8f,%.8f]", lon, lat));
    }

    private static void ring(StringBuilder b, double[] r) {
        b.append('[');
        int n = r.length / 2;
        for (int i = 0; i < n; i++) {
            if (i > 0) b.append(',');
            pos(b, r[2 * i], r[2 * i + 1]);
        }
        // GeoJSON requires closed rings
        if (n > 0 && (r[0] != r[2 * n - 2] || r[1] != r[2 * n - 1])) {
            b.append(',');
            pos(b, r[0], r[1]);
        }
        b.append(']');
    }

    static String geometry(Feature f) {
        StringBuilder b = new StringBuilder();
        if (f.geom == Feature.POINT) {
            double[] p = f.parts.isEmpty() ? new double[]{f.lon, f.lat} : f.parts.get(0);
            b.append("{\"type\":\"Point\",\"coordinates\":");
            pos(b, p[0], p[1]);
            return b.append('}').toString();
        }
        if (f.geom == Feature.LINE) {
            boolean multi = f.parts.size() > 1;
            b.append(multi ? "{\"type\":\"MultiLineString\",\"coordinates\":[" : "{\"type\":\"LineString\",\"coordinates\":");
            for (int k = 0; k < f.parts.size(); k++) {
                if (k > 0) b.append(',');
                double[] p = f.parts.get(k);
                b.append('[');
                for (int i = 0; i < p.length / 2; i++) {
                    if (i > 0) b.append(',');
                    pos(b, p[2 * i], p[2 * i + 1]);
                }
                b.append(']');
            }
            return b.append(multi ? "]}" : "}").toString();
        }
        // polygons: an outer ring starts a polygon, following holes belong to it
        List<List<double[]>> polys = new ArrayList<>();
        for (int k = 0; k < f.parts.size(); k++) {
            if (!f.isHole(k) || polys.isEmpty()) polys.add(new ArrayList<double[]>());
            polys.get(polys.size() - 1).add(f.parts.get(k));
        }
        boolean multi = polys.size() > 1;
        b.append(multi ? "{\"type\":\"MultiPolygon\",\"coordinates\":[" : "{\"type\":\"Polygon\",\"coordinates\":");
        for (int p = 0; p < polys.size(); p++) {
            if (p > 0) b.append(',');
            b.append('[');
            List<double[]> rs = polys.get(p);
            for (int r = 0; r < rs.size(); r++) {
                if (r > 0) b.append(',');
                ring(b, rs.get(r));
            }
            b.append(']');
        }
        return b.append(multi ? "]}" : "}").toString();
    }

    public static void write(List<LayerData> layers, OutputStream os) throws IOException {
        Writer w = new BufferedWriter(new OutputStreamWriter(os, UTF8), 1 << 16);
        w.write("{\"type\":\"FeatureCollection\",\"name\":\"PoiExporter\",\"features\":[\n");
        boolean first = true;
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                Utm.Result u = Utm.fromLatLon(f.lat, f.lon);
                if (!first) w.write(",\n");
                first = false;
                w.write("{\"type\":\"Feature\",\"properties\":{");
                w.write("\"layer\":\"" + esc(l.label) + "\",\"name\":\"" + esc(f.name) + "\",\"type\":\"" + esc(f.type)
                        + "\",\"category\":\"" + esc(f.category) + "\",\"nahiya\":\"" + esc(f.nahiya)
                        + "\",\"qada\":\"" + esc(f.qadaa) + "\",\"governorate\":\"" + esc(f.governorate)
                        + "\",\"notes\":\"" + esc(f.notes) + "\",\"osm_id\":\"" + esc(f.id) + "\",\"utm_zone\":\""
                        + esc(u.zoneLabel()) + "\",");
                w.write(String.format(Locale.US, "\"X\":%.2f,\"Y\":%.2f", u.easting, u.northing));
                w.write("},\"geometry\":" + geometry(f) + "}");
            }
        }
        w.write("\n]}\n");
        w.flush();
    }
}
