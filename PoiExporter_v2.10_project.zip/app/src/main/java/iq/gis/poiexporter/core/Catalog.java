package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/** What can be downloaded: point-of-interest categories and the extra map layers. */
public final class Catalog {
    /** One OSM tag test: key with a set of values (empty = any value). */
    public static final class Clause {
        public final String key;
        public final String[] values;

        Clause(String key, String... values) {
            this.key = key;
            this.values = values;
        }

        public String selector() {
            if (values.length == 0) return "[\"" + key + "\"]";
            StringBuilder sb = new StringBuilder("[\"" + key + "\"~\"^(");
            for (int i = 0; i < values.length; i++) sb.append(i > 0 ? "|" : "").append(values[i]);
            return sb.append(")$\"]").toString();
        }

        public boolean matches(java.util.Map<String, String> tags) {
            String v = tags.get(key);
            if (v == null || v.isEmpty()) return false;
            if (values.length == 0) return true;
            for (String s : values) if (s.equals(v)) return true;
            return false;
        }
    }

    public static final class PoiCat {
        public final String id, ar, en;
        public final Clause[] clauses;

        PoiCat(String id, String ar, String en, Clause... clauses) {
            this.id = id;
            this.ar = ar;
            this.en = en;
            this.clauses = clauses;
        }

        public String label(boolean arabic) {
            return arabic ? ar : en;
        }
    }

    public static final String K_POI = "poi";
    public static final String K_ROADS_MAIN = "roads_main", K_ROADS_SEC = "roads_secondary", K_RIVERS = "rivers",
            K_LAKES = "lakes", K_DAMS = "dams", K_TOURISM = "tourism",
            K_ADMIN_GOV = "admin_gov", K_ADMIN_QADAA = "admin_qadaa", K_ADMIN_NAHIYA = "admin_nahiya";

    /** A non-POI layer. */
    public static final class LayerDef {
        public final String id, ar, en;
        public final int geom;
        public final Clause[] clauses; // any clause matching selects the element
        public final String extra; // extra Overpass filter text appended to every statement
        public final String typeHint;

        LayerDef(String id, String ar, String en, int geom, String extra, Clause... clauses) {
            this.id = id;
            this.ar = ar;
            this.en = en;
            this.geom = geom;
            this.extra = extra;
            this.clauses = clauses;
            this.typeHint = clauses[0].key;
        }

        public String label(boolean arabic) {
            return arabic ? ar : en;
        }
    }

    public static final PoiCat[] POI = {
            new PoiCat("school", "مدارس", "Schools", new Clause("amenity", "school", "kindergarten")),
            new PoiCat("university", "جامعات وكليات", "Universities and colleges", new Clause("amenity", "university", "college")),
            new PoiCat("hospital", "مستشفيات", "Hospitals", new Clause("amenity", "hospital")),
            new PoiCat("clinic", "عيادات ومراكز صحية", "Clinics", new Clause("amenity", "clinic", "doctors", "dentist")),
            new PoiCat("pharmacy", "صيدليات", "Pharmacies", new Clause("amenity", "pharmacy")),
            new PoiCat("worship", "مساجد ودور عبادة", "Places of worship", new Clause("amenity", "place_of_worship")),
            new PoiCat("food", "مطاعم ومقاهي", "Restaurants and cafes", new Clause("amenity", "restaurant", "cafe", "fast_food")),
            new PoiCat("bank", "مصارف", "Banks", new Clause("amenity", "bank")),
            new PoiCat("fuel", "محطات وقود", "Fuel stations", new Clause("amenity", "fuel")),
            new PoiCat("hotel", "فنادق", "Hotels", new Clause("tourism", "hotel", "guest_house", "motel")),
            new PoiCat("police", "شرطة وأمن", "Police", new Clause("amenity", "police")),
            new PoiCat("gov", "دوائر حكومية", "Government offices", new Clause("amenity", "townhall", "courthouse"), new Clause("office", "government")),
            new PoiCat("shop", "متاجر وأسواق", "Shops", new Clause("shop")),
            new PoiCat("market", "أسواق شعبية", "Marketplaces", new Clause("amenity", "marketplace")),
            new PoiCat("sport", "ملاعب ورياضة", "Sports", new Clause("leisure", "stadium", "sports_centre")),
            new PoiCat("airport", "مطارات", "Airports", new Clause("aeroway", "aerodrome")),
    };

    private static final String WATER_NOT_RIVER = "[\"water\"!~\"^(river|stream|canal|ditch|drain|oxbow)$\"]";

    public static final LayerDef[] LAYERS = {
            new LayerDef(K_ROADS_MAIN, "الطرق الرئيسية", "Main roads", Feature.LINE, "",
                    new Clause("highway", "motorway", "trunk", "primary", "motorway_link", "trunk_link", "primary_link")),
            new LayerDef(K_ROADS_SEC, "الطرق الثانوية والفرعية", "Secondary & minor roads", Feature.LINE, "",
                    new Clause("highway", "secondary", "tertiary", "secondary_link", "tertiary_link", "unclassified", "residential", "living_street", "road")),
            new LayerDef(K_RIVERS, "الأنهار", "Rivers", Feature.LINE, "",
                    new Clause("waterway", "river", "canal")),
            new LayerDef(K_LAKES, "البحيرات", "Lakes", Feature.POLYGON, WATER_NOT_RIVER,
                    new Clause("natural", "water")),
            new LayerDef(K_DAMS, "السدود", "Dams", Feature.POINT, "",
                    new Clause("waterway", "dam"), new Clause("man_made", "dam")),
            new LayerDef(K_TOURISM, "المعالم السياحية", "Tourist sites", Feature.POINT, "",
                    new Clause("tourism", "attraction", "museum", "viewpoint", "zoo", "theme_park", "gallery"),
                    new Clause("historic")),
    };

    public static final String[] ADMIN_IDS = {K_ADMIN_GOV, K_ADMIN_QADAA, K_ADMIN_NAHIYA};

    public static String adminLabel(int idx, boolean arabic) {
        String[] ar = {"حدود المحافظات", "حدود الأقضية", "حدود النواحي"};
        String[] en = {"Governorate boundaries", "District (qadaa) boundaries", "Sub-district (nahiya) boundaries"};
        return arabic ? ar[idx] : en[idx];
    }

    public static PoiCat poi(String id) {
        for (PoiCat c : POI) if (c.id.equals(id)) return c;
        return null;
    }

    public static LayerDef layer(String id) {
        for (LayerDef d : LAYERS) if (d.id.equals(id)) return d;
        return null;
    }

    /** Overpass statements for the selected POI categories. */
    public static List<String> poiStatements(List<String> ids, String custom, boolean includeUnnamed, AreaSpec a) {
        List<String> out = new ArrayList<>();
        String named = includeUnnamed ? "" : "[\"name\"]";
        for (String id : ids) {
            PoiCat c = poi(id);
            if (c == null) continue;
            for (Clause cl : c.clauses) out.add("nwr" + cl.selector() + named + a.overpass() + ";");
        }
        String cs = customSelector(custom);
        if (cs != null) out.add("nwr" + cs + named + a.overpass() + ";");
        return out;
    }

    /** Accepts "key=value", "key=a|b" or "key"; null when empty. */
    public static String customSelector(String raw) {
        if (raw == null) return null;
        raw = raw.trim();
        if (raw.isEmpty()) return null;
        String[] kv = raw.split("=", 2);
        String ok = "[A-Za-z0-9_:\\-|]+";
        if (!kv[0].matches(ok)) throw new IllegalArgumentException("Invalid filter: " + raw);
        if (kv.length == 1 || kv[1].isEmpty()) return "[\"" + kv[0] + "\"]";
        if (!kv[1].matches(ok)) throw new IllegalArgumentException("Invalid filter: " + raw);
        if (kv[1].contains("|")) return "[\"" + kv[0] + "\"~\"^(" + kv[1] + ")$\"]";
        return "[\"" + kv[0] + "\"=\"" + kv[1] + "\"]";
    }
}
