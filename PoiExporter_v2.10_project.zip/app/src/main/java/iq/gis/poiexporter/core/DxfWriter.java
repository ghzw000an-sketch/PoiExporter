package iq.gis.poiexporter.core;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * AutoCAD DXF (R12, ASCII) in UTM metres. One layer per exported layer; every feature also gets a
 * TEXT label with its name (non-ASCII characters are written as \U+XXXX escapes).
 */
public final class DxfWriter {
    private static final Charset ASCII = Charset.forName("US-ASCII");

    private DxfWriter() {
    }

    static String text(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0x20 && c < 0x7F) b.append(c);
            else if (c == '\n' || c == '\r' || c == '\t') b.append(' ');
            else if (c >= 0x7F) b.append(String.format("\\U+%04X", (int) c));
        }
        return b.toString();
    }

    static String layerName(int idx, String label) {
        StringBuilder b = new StringBuilder("L" + (idx + 1) + "_");
        for (int i = 0; i < label.length() && b.length() < 28; i++) {
            char c = label.charAt(i);
            b.append((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ? c : '_');
        }
        return b.toString();
    }

    private static void g(Writer w, int code, String v) throws IOException {
        w.write(code + "\n" + v + "\n");
    }

    private static String n(double v) {
        return String.format(Locale.US, "%.3f", v);
    }

    public static void write(List<LayerData> layers, OutputStream os) throws IOException {
        Writer w = new BufferedWriter(new OutputStreamWriter(os, ASCII), 1 << 16);
        int zone = 0;
        for (LayerData l : layers) {
            if (!l.features.isEmpty()) {
                zone = Utm.zoneFor(l.features.get(0).lon);
                break;
            }
        }
        if (zone == 0) zone = 38;
        List<String> names = new ArrayList<>();
        for (int i = 0; i < layers.size(); i++) names.add(layerName(i, layers.get(i).label));

        g(w, 999, "PoiExporter - UTM zone " + zone + " (WGS84), metres");
        g(w, 0, "SECTION");
        g(w, 2, "HEADER");
        g(w, 9, "$ACADVER");
        g(w, 1, "AC1009");
        g(w, 0, "ENDSEC");
        g(w, 0, "SECTION");
        g(w, 2, "TABLES");
        g(w, 0, "TABLE");
        g(w, 2, "LAYER");
        g(w, 70, String.valueOf(names.size() + 1));
        List<String> all = new ArrayList<>();
        all.add("0");
        all.addAll(names);
        for (String nm : all) {
            g(w, 0, "LAYER");
            g(w, 2, nm);
            g(w, 70, "0");
            g(w, 62, "7");
            g(w, 6, "CONTINUOUS");
        }
        g(w, 0, "ENDTAB");
        g(w, 0, "ENDSEC");
        g(w, 0, "SECTION");
        g(w, 2, "ENTITIES");
        for (int li = 0; li < layers.size(); li++) {
            LayerData l = layers.get(li);
            String ly = names.get(li);
            for (Feature f : l.features) {
                double[] lab = null;
                if (f.geom == Feature.POINT) {
                    Utm.Result u = Utm.fromLatLon(f.lat, f.lon, zone);
                    g(w, 0, "POINT");
                    g(w, 8, ly);
                    g(w, 10, n(u.easting));
                    g(w, 20, n(u.northing));
                    g(w, 30, "0");
                    lab = new double[]{u.easting, u.northing};
                } else {
                    for (double[] part : f.parts) {
                        int cnt = part.length / 2;
                        if (cnt < 2) continue;
                        g(w, 0, "POLYLINE");
                        g(w, 8, ly);
                        g(w, 66, "1");
                        g(w, 70, f.geom == Feature.POLYGON ? "1" : "0");
                        for (int i = 0; i < cnt; i++) {
                            Utm.Result u = Utm.fromLatLon(part[2 * i + 1], part[2 * i], zone);
                            g(w, 0, "VERTEX");
                            g(w, 8, ly);
                            g(w, 10, n(u.easting));
                            g(w, 20, n(u.northing));
                            g(w, 30, "0");
                        }
                        g(w, 0, "SEQEND");
                        g(w, 8, ly);
                    }
                    Utm.Result u = Utm.fromLatLon(f.lat, f.lon, zone);
                    lab = new double[]{u.easting, u.northing};
                }
                String t = text(f.name);
                if (!t.isEmpty() && lab != null) {
                    g(w, 0, "TEXT");
                    g(w, 8, ly);
                    g(w, 10, n(lab[0]));
                    g(w, 20, n(lab[1]));
                    g(w, 30, "0");
                    g(w, 40, "8");
                    g(w, 1, t);
                }
            }
        }
        g(w, 0, "ENDSEC");
        g(w, 0, "EOF");
        w.flush();
    }
}
