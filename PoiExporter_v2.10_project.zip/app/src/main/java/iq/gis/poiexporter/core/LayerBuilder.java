package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Turns Overpass elements into features of one layer. */
public final class LayerBuilder {
    private LayerBuilder() {}

    public static String nameOf(Overpass.Elem e) {
        String n = e.tag("name:ar");
        if (n.isEmpty()) n = e.tag("name");
        if (n.isEmpty()) n = e.tag("name:en");
        return n;
    }

    /** Feature for a point layer from a node or from the centre of a way or relation. */
    public static Feature pointFrom(Overpass.Elem e) {
        double lat = e.lat, lon = e.lon;
        if (Double.isNaN(lat) || Double.isNaN(lon)) {
            if (e.geom != null && e.geom.length >= 2) {
                Feature tmp = new Feature();
                tmp.geom = Feature.LINE;
                tmp.addPart(e.geom, false);
                Geo.setRepresentative(tmp);
                lat = tmp.lat;
                lon = tmp.lon;
            } else {
                return null;
            }
        }
        Feature f = Feature.point(lat, lon);
        f.id = e.type + "/" + e.id;
        f.name = nameOf(e);
        return f;
    }

    public static Feature lineFrom(Overpass.Elem e) {
        if (e.geom == null || e.geom.length < 4) return null;
        Feature f = new Feature();
        f.geom = Feature.LINE;
        f.id = e.type + "/" + e.id;
        f.name = nameOf(e);
        f.addPart(e.geom, false);
        Geo.setRepresentative(f);
        return f;
    }

    /** Polygon from a closed way or from a multipolygon / boundary relation. Null if no ring can be built. */
    public static Feature polygonFrom(Overpass.Elem e) {
        Feature f = new Feature();
        f.geom = Feature.POLYGON;
        f.id = e.type + "/" + e.id;
        f.name = nameOf(e);
        if (e.members != null) {
            List<double[]> outers = new ArrayList<>(), inners = new ArrayList<>();
            for (Overpass.Member m : e.members) {
                if (!"way".equals(m.type) || m.geom == null || m.geom.length < 4) continue;
                if ("inner".equals(m.role)) inners.add(m.geom);
                else if (m.role.isEmpty() || "outer".equals(m.role)) outers.add(m.geom);
            }
            List<double[]> o = RingBuilder.build(outers);
            if (o.isEmpty()) return null;
            for (double[] r : o) f.addPart(r, false);
            for (double[] r : RingBuilder.build(inners)) f.addPart(r, true);
        } else if (e.geom != null && e.geom.length >= 8) {
            int n = e.geom.length;
            if (e.geom[0] != e.geom[n - 2] || e.geom[1] != e.geom[n - 1]) return null;
            f.addPart(e.geom, false);
        } else {
            return null;
        }
        Geo.setRepresentative(f);
        return f;
    }

    /** Builds the features of a non-POI layer; categoryLabel is stored in CATEGORY. */
    public static List<Feature> build(List<Overpass.Elem> elems, Catalog.LayerDef def, boolean arabic) {
        List<Feature> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Overpass.Elem e : elems) {
            Feature f = null;
            switch (def.geom) {
                case Feature.POINT: f = pointFrom(e); break;
                case Feature.LINE:
                    if (!"way".equals(e.type)) continue;
                    f = lineFrom(e);
                    break;
                default:
                    f = polygonFrom(e);
            }
            if (f == null || !seen.add(f.id)) continue;
            String type = "", cat = def.label(arabic);
            for (Catalog.Clause c : def.clauses) {
                if (c.matches(e.tags)) {
                    type = c.key + "=" + e.tag(c.key);
                    break;
                }
            }
            f.type = type;
            f.category = cat;
            out.add(f);
        }
        return out;
    }

    /** POI features, with type and category taken from the first selected category that matches. */
    public static List<Feature> buildPois(List<Overpass.Elem> elems, List<String> catIds, String custom, boolean arabic) {
        List<Feature> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String customKey = null;
        String cs = Catalog.customSelector(custom);
        if (cs != null) customKey = custom.trim().split("=", 2)[0];
        for (Overpass.Elem e : elems) {
            Feature f = pointFrom(e);
            if (f == null || !seen.add(f.id)) continue;
            boolean done = false;
            for (String id : catIds) {
                Catalog.PoiCat c = Catalog.poi(id);
                if (c == null) continue;
                for (Catalog.Clause cl : c.clauses) {
                    if (cl.matches(e.tags)) {
                        f.type = cl.key + "=" + e.tag(cl.key);
                        f.category = c.label(arabic);
                        done = true;
                        break;
                    }
                }
                if (done) break;
            }
            if (!done) {
                if (customKey != null && !e.tag(customKey).isEmpty()) {
                    f.type = customKey + "=" + e.tag(customKey);
                    f.category = arabic ? "مخصص" : "Custom";
                }
            }
            out.add(f);
        }
        return out;
    }

    /** Levels found in the tags, used to name admin features. */
    public static int adminLevel(Map<String, String> tags) {
        try {
            return Integer.parseInt(tags.get("admin_level"));
        } catch (Exception ex) {
            return -1;
        }
    }
}
