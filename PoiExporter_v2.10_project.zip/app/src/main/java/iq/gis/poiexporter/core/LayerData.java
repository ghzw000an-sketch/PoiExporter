package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/** A set of features of one geometry type that is shown, saved and exported together. */
public final class LayerData {
    public final String id;
    public String label;
    public final int geom;
    /** 0 = default colour of the layer; otherwise 0xFFRRGGBB. */
    public int color;
    public final List<Feature> features = new ArrayList<>();

    public LayerData(String id, String label, int geom) {
        this.id = id;
        this.label = label;
        this.geom = geom;
    }

    public static String geomName(int g) {
        return g == Feature.POINT ? "point" : g == Feature.LINE ? "line" : "polygon";
    }
}
