package iq.gis.poiexporter;

import android.content.Context;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Kml;
import iq.gis.poiexporter.core.LayerData;

/** Saved landmark groups, one KML file each inside the app's private storage. */
public final class Library {
    private Library() {
    }

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "library");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static String newId() {
        return "grp_" + System.currentTimeMillis() + "_" + (int) (Math.random() * 1000);
    }

    public static List<LayerData> loadAll(Context c) {
        List<LayerData> out = new ArrayList<>();
        File[] fs = dir(c).listFiles();
        if (fs == null) return out;
        Arrays.sort(fs, new Comparator<File>() {
            public int compare(File a, File b) {
                return a.getName().compareTo(b.getName());
            }
        });
        for (File f : fs) {
            if (!f.getName().endsWith(".kml")) continue;
            String id = f.getName().substring(0, f.getName().length() - 4);
            try {
                InputStream in = new FileInputStream(f);
                try {
                    List<LayerData> ls = Kml.read(in, f.getName());
                    LayerData g = null;
                    for (LayerData l : ls) {
                        if (g == null) g = new LayerData(id, l.label, l.geom);
                        if (g.color == 0) g.color = l.color;
                        g.features.addAll(l.features);
                    }
                    if (g != null) out.add(g);
                } finally {
                    in.close();
                }
            } catch (Exception ignored) {
                // damaged file: skip it
            }
        }
        return out;
    }

    public static void save(Context c, LayerData g) throws IOException {
        File f = new File(dir(c), g.id + ".kml");
        List<LayerData> one = new ArrayList<>();
        one.add(g);
        OutputStream os = new BufferedOutputStream(new FileOutputStream(f));
        try {
            Kml.write(one, g.label, CoordFmt.Fmt.DD, false, os);
        } finally {
            os.close();
        }
    }

    public static void delete(Context c, LayerData g) {
        new File(dir(c), g.id + ".kml").delete();
    }

    public static boolean isGroup(LayerData l) {
        return l.id.startsWith("grp_");
    }

    /** First point geometry of mixed groups. */
    public static int geomOf(List<Feature> fs, int def) {
        return fs.isEmpty() ? def : fs.get(0).geom;
    }
}
