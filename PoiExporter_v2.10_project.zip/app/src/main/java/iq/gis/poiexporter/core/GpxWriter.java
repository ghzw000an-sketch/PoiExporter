package iq.gis.poiexporter.core;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Locale;

/** GPX 1.1: points as waypoints, lines and polygon rings as tracks. */
public final class GpxWriter {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private GpxWriter() {
    }

    static String x(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < 0x20 && c != '\n' && c != '\r' && c != '\t') continue;
            switch (c) {
                case '&': b.append("&amp;"); break;
                case '<': b.append("&lt;"); break;
                case '>': b.append("&gt;"); break;
                case '"': b.append("&quot;"); break;
                default: b.append(c);
            }
        }
        return b.toString();
    }

    private static String desc(LayerData l, Feature f) {
        StringBuilder b = new StringBuilder();
        String[] parts = {f.category.isEmpty() ? l.label : f.category, f.qadaa, f.nahiya, f.notes};
        for (String p : parts) {
            if (p == null || p.isEmpty()) continue;
            if (b.length() > 0) b.append(" - ");
            b.append(p);
        }
        return b.toString();
    }

    public static void write(List<LayerData> layers, OutputStream os) throws IOException {
        Writer w = new BufferedWriter(new OutputStreamWriter(os, UTF8), 1 << 16);
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"PoiExporter\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                String nm = f.name.isEmpty() ? f.type : f.name;
                if (f.geom == Feature.POINT) {
                    double[] p = f.parts.isEmpty() ? new double[]{f.lon, f.lat} : f.parts.get(0);
                    w.write(String.format(Locale.US, "<wpt lat=\"%.8f\" lon=\"%.8f\"><name>%s</name><desc>%s</desc><type>%s</type></wpt>\n",
                            p[1], p[0], x(nm), x(desc(l, f)), x(f.type)));
                    continue;
                }
                w.write("<trk><name>" + x(nm) + "</name><desc>" + x(desc(l, f)) + "</desc><type>" + x(f.type) + "</type>");
                for (double[] part : f.parts) {
                    int n = part.length / 2;
                    w.write("<trkseg>");
                    for (int i = 0; i < n; i++) {
                        w.write(String.format(Locale.US, "<trkpt lat=\"%.8f\" lon=\"%.8f\"/>", part[2 * i + 1], part[2 * i]));
                    }
                    if (f.geom == Feature.POLYGON && n > 0 && (part[0] != part[2 * n - 2] || part[1] != part[2 * n - 1])) {
                        w.write(String.format(Locale.US, "<trkpt lat=\"%.8f\" lon=\"%.8f\"/>", part[1], part[0]));
                    }
                    w.write("</trkseg>");
                }
                w.write("</trk>\n");
            }
        }
        w.write("</gpx>\n");
        w.flush();
    }
}
