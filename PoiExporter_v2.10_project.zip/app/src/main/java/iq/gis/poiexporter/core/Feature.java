package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/** One geometry with its attributes. Coordinates are WGS84, interleaved lon,lat. */
public final class Feature {
    public static final int POINT = 1, LINE = 3, POLYGON = 5;

    public int geom;
    public String id = "", name = "", type = "", category = "", nahiya = "", qadaa = "", governorate = "";
    /** Free notes / details written by the user. */
    public String notes = "";
    /** 0 = use the colour of the layer; otherwise 0xFFRRGGBB. */
    public int color;
    /** Hidden on the map (kept in the group and in exports). */
    public boolean hidden;
    /** Parts of the geometry. A point has one part with one coordinate pair. */
    public final List<double[]> parts = new ArrayList<>();
    /** Parallel to parts for polygons: true if the ring is a hole. */
    public final List<Boolean> holes = new ArrayList<>();
    /** Representative point (on the line, inside the polygon where possible). */
    public double lat, lon;

    public static Feature point(double lat, double lon) {
        Feature f = new Feature();
        f.geom = POINT;
        f.parts.add(new double[]{lon, lat});
        f.holes.add(Boolean.FALSE);
        f.lat = lat;
        f.lon = lon;
        return f;
    }

    public void addPart(double[] coords, boolean hole) {
        parts.add(coords);
        holes.add(hole);
    }

    public boolean isHole(int i) {
        return i < holes.size() && holes.get(i);
    }
}
