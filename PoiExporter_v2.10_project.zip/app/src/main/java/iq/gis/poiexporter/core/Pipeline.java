package iq.gis.poiexporter.core;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Downloads every selected layer for an area and prepares it for display and export. */
public final class Pipeline {
    public interface Fetcher {
        /** Runs an Overpass query and returns the JSON response stream. */
        InputStream post(String query) throws IOException;
    }

    public interface Progress {
        void update(String message, int step, int steps);

        boolean cancelled();
    }

    public static final class Params {
        public AreaSpec area;
        public List<String> poiCats = new ArrayList<>();
        public String custom = "";
        public boolean includeUnnamed;
        public Set<String> layerIds = new LinkedHashSet<>();
        public boolean fillAdmin;
        public int[] adminLevels = {4, 5, 6};
        public boolean arabic = true;
    }

    public static final class Result {
        public final List<LayerData> layers = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        public boolean cancelled;

        public int featureCount() {
            int n = 0;
            for (LayerData l : layers) n += l.features.size();
            return n;
        }
    }

    private static final int INDEX_MAX_VERTICES = 20000;

    private Pipeline() {}

    static String header() {
        return "[out:json][timeout:600][maxsize:1073741824];";
    }

    public static String poiQuery(Params p) {
        List<String> st = Catalog.poiStatements(p.poiCats, p.custom, p.includeUnnamed, p.area);
        if (st.isEmpty()) return null;
        StringBuilder sb = new StringBuilder(header()).append("(");
        for (String s : st) sb.append(s);
        return sb.append(");out center qt;").toString();
    }

    public static String layerQuery(Catalog.LayerDef d, AreaSpec a) {
        StringBuilder sb = new StringBuilder(header()).append("(");
        for (Catalog.Clause c : d.clauses) {
            String type = d.geom == Feature.LINE ? "way" : "nwr";
            sb.append(type).append(c.selector()).append(d.extra).append(a.overpass()).append(";");
        }
        sb.append(");");
        sb.append(d.geom == Feature.POINT ? "out center qt;" : "out geom qt;");
        return sb.toString();
    }

    public static String adminQuery(int[] levels, AreaSpec a) {
        StringBuilder lv = new StringBuilder();
        Set<Integer> seen = new LinkedHashSet<>();
        for (int l : levels) if (seen.add(l)) lv.append(lv.length() > 0 ? "|" : "").append(l);
        return header() + "rel[\"boundary\"=\"administrative\"][\"admin_level\"~\"^(" + lv + ")$\"]" + a.overpass() + ";out geom qt;";
    }

    private static List<Overpass.Elem> fetch(Fetcher f, String q, final Progress pr) throws IOException {
        final List<Overpass.Elem> out = new ArrayList<>();
        InputStream in = f.post(q);
        try {
            Overpass.parse(in, new Overpass.Sink() {
                public boolean accept(Overpass.Elem e) {
                    out.add(e);
                    return !pr.cancelled();
                }
            });
        } finally {
            try {
                in.close();
            } catch (IOException ignored) {
                // nothing to do
            }
        }
        return out;
    }

    private static final class Task {
        LayerData layer;
        AdminIndex index;
        List<Feature>[] admin;
        String warning;
    }

    /** Runs all downloads in parallel (3 at a time) to cut the waiting time. */
    public static Result run(final Params p, final Fetcher fetcher, final Progress pr) {
        final Result res = new Result();
        final List<Catalog.LayerDef> defs = new ArrayList<>();
        for (Catalog.LayerDef d : Catalog.LAYERS) if (p.layerIds.contains(d.id)) defs.add(d);
        final boolean[] adminWanted = new boolean[3];
        boolean anyAdminLayer = false;
        for (int i = 0; i < 3; i++) {
            adminWanted[i] = p.layerIds.contains(Catalog.ADMIN_IDS[i]);
            anyAdminLayer |= adminWanted[i];
        }
        final String poiQ = p.poiCats.isEmpty() && (p.custom == null || p.custom.trim().isEmpty()) ? null : poiQuery(p);
        final boolean needAdmin = p.fillAdmin || anyAdminLayer;
        final int steps = (poiQ != null ? 1 : 0) + defs.size() + (needAdmin ? 1 : 0);
        final java.util.concurrent.atomic.AtomicInteger step = new java.util.concurrent.atomic.AtomicInteger();
        java.util.concurrent.ExecutorService ex = java.util.concurrent.Executors.newFixedThreadPool(3);
        java.util.concurrent.Future<Task> adminF = null, poiF = null;
        List<java.util.concurrent.Future<Task>> layerFs = new ArrayList<>();
        try {
            if (needAdmin) {
                adminF = ex.submit(new java.util.concurrent.Callable<Task>() {
                    @SuppressWarnings("unchecked")
                    public Task call() {
                        Task t = new Task();
                        pr.update("admin", step.incrementAndGet(), steps);
                        try {
                            List<Feature>[] byLevel = new List[3];
                            for (int i = 0; i < 3; i++) byLevel[i] = new ArrayList<>();
                            List<Overpass.Elem> els = fetch(fetcher, adminQuery(p.adminLevels, p.area), pr);
                            AdminIndex index = new AdminIndex();
                            for (Overpass.Elem e : els) {
                                int level = LayerBuilder.adminLevel(e.tags);
                                Feature poly = LayerBuilder.polygonFrom(e);
                                if (poly == null) continue;
                                poly.type = "admin_level=" + level;
                                for (int i = 0; i < 3; i++) {
                                    if (p.adminLevels[i] == level) {
                                        byLevel[i].add(poly);
                                        index.add(level, simplified(poly));
                                    }
                                }
                            }
                            t.admin = byLevel;
                            t.index = index;
                            if (index.size() == 0) t.warning = "admin:none";
                        } catch (IOException e) {
                            t.warning = "admin:" + e.getMessage();
                        }
                        return t;
                    }
                });
            }
            if (poiQ != null) {
                poiF = ex.submit(new java.util.concurrent.Callable<Task>() {
                    public Task call() {
                        Task t = new Task();
                        pr.update("poi", step.incrementAndGet(), steps);
                        try {
                            List<Feature> feats = LayerBuilder.buildPois(fetch(fetcher, poiQ, pr), p.poiCats, p.custom, p.arabic);
                            t.layer = new LayerData(Catalog.K_POI, p.arabic ? "المعالم" : "Landmarks", Feature.POINT);
                            t.layer.features.addAll(feats);
                        } catch (IOException e) {
                            t.warning = "poi:" + e.getMessage();
                        }
                        return t;
                    }
                });
            }
            for (final Catalog.LayerDef d : defs) {
                layerFs.add(ex.submit(new java.util.concurrent.Callable<Task>() {
                    public Task call() {
                        Task t = new Task();
                        pr.update(d.id, step.incrementAndGet(), steps);
                        try {
                            List<Feature> feats = LayerBuilder.build(fetch(fetcher, layerQuery(d, p.area), pr), d, p.arabic);
                            t.layer = new LayerData(d.id, d.label(p.arabic), d.geom);
                            t.layer.features.addAll(feats);
                        } catch (IOException e) {
                            t.warning = d.id + ":" + e.getMessage();
                        }
                        return t;
                    }
                }));
            }
            AdminIndex index = null;
            List<Feature>[] adminFeatures = null;
            if (adminF != null) {
                Task t = adminF.get();
                index = t.index;
                adminFeatures = t.admin;
                if (t.warning != null) res.warnings.add(t.warning);
            }
            List<java.util.concurrent.Future<Task>> ordered = new ArrayList<>();
            if (poiF != null) ordered.add(poiF);
            ordered.addAll(layerFs);
            for (java.util.concurrent.Future<Task> f : ordered) {
                Task t = f.get();
                if (t.layer != null) res.layers.add(t.layer);
                if (t.warning != null) res.warnings.add(t.warning);
            }
            if (pr.cancelled()) {
                res.cancelled = true;
                finish(res, p, index);
                return res;
            }
            if (adminFeatures != null) {
                for (int i = 0; i < 3; i++) {
                    if (!adminWanted[i]) continue;
                    LayerData l = new LayerData(Catalog.ADMIN_IDS[i], Catalog.adminLabel(i, p.arabic), Feature.POLYGON);
                    for (Feature f : adminFeatures[i]) {
                        f.category = Catalog.adminLabel(i, p.arabic);
                        l.features.add(f);
                    }
                    res.layers.add(l);
                }
            }
            finish(res, p, index);
            return res;
        } catch (InterruptedException | java.util.concurrent.ExecutionException e) {
            res.warnings.add("run:" + e.getMessage());
            res.cancelled = pr.cancelled();
            return res;
        } finally {
            ex.shutdownNow();
        }
    }

    private static void finish(Result res, Params p, AdminIndex index) {
        for (LayerData l : res.layers) {
            boolean isAdmin = l.id.startsWith("admin_");
            if ((p.area.circle || p.area.isRotated()) && !isAdmin) {
                List<Feature> keep = new ArrayList<>();
                for (Feature f : l.features) if (f.geom != Feature.POINT || p.area.contains(f.lat, f.lon)) keep.add(f);
                l.features.clear();
                l.features.addAll(keep);
            }
            if (p.fillAdmin && index != null && !isAdmin) {
                for (Feature f : l.features) Geo.fillAdmin(f, index, p.adminLevels);
            }
        }
    }

    /** Fills governorate/qadaa/nahiya of hand-made points from OSM boundaries around them. */
    public static void fillAdminFor(List<Feature> feats, int[] levels, Fetcher fetcher) throws IOException {
        if (feats.isEmpty()) return;
        double s = 90, w = 180, n = -90, e = -180;
        for (Feature f : feats) {
            s = Math.min(s, f.lat);
            n = Math.max(n, f.lat);
            w = Math.min(w, f.lon);
            e = Math.max(e, f.lon);
        }
        AreaSpec a = AreaSpec.rect(s - 0.001, w - 0.001, n + 0.001, e + 0.001);
        Progress none = new Progress() {
            public void update(String m, int st, int sts) {
            }

            public boolean cancelled() {
                return false;
            }
        };
        AdminIndex index = new AdminIndex();
        for (Overpass.Elem el : fetch(fetcher, adminQuery(levels, a), none)) {
            int level = LayerBuilder.adminLevel(el.tags);
            Feature poly = LayerBuilder.polygonFrom(el);
            if (poly == null) continue;
            for (int i = 0; i < 3; i++) if (levels[i] == level) index.add(level, simplified(poly));
        }
        for (Feature f : feats) Geo.fillAdmin(f, index, levels);
    }

    /** Copy of a polygon with each ring cut to a manageable number of vertices for point-in-polygon tests. */
    static Feature simplified(Feature poly) {
        Feature c = new Feature();
        c.geom = Feature.POLYGON;
        c.name = poly.name;
        for (int i = 0; i < poly.parts.size(); i++) c.addPart(Geo.decimate(poly.parts.get(i), INDEX_MAX_VERTICES), poly.isHole(i));
        c.lat = poly.lat;
        c.lon = poly.lon;
        return c;
    }
}
