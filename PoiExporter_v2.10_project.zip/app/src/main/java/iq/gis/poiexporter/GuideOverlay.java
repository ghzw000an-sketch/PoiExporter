package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.Typeface;

import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

import java.util.Locale;

import iq.gis.poiexporter.core.Geo;

/**
 * Guidance line: a continuous line from the centre of the screen to a chosen target point,
 * with the distance written on the line. It follows the map while it is moved.
 */
public final class GuideOverlay extends Overlay {
    private boolean on;
    private double lat, lon;
    private final float d;
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG),
            pill = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG),
            mark = new Paint(Paint.ANTI_ALIAS_FLAG), markRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrow = new Path();
    private final RectF rc = new RectF();

    public GuideOverlay(float density) {
        d = density;
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeCap(Paint.Cap.ROUND);
        halo.setColor(0xFFFFFFFF);
        halo.setStrokeWidth(7f * d);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(0xFFE8590C);
        line.setStrokeWidth(3.2f * d);
        pill.setColor(0xEE1B2733);
        txt.setColor(0xFFFFFFFF);
        txt.setTextSize(13f * d);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        txt.setTextAlign(Paint.Align.CENTER);
        mark.setColor(0xFFE8590C);
        markRing.setColor(0xFFFFFFFF);
    }

    public void set(double lat, double lon) {
        this.lat = lat;
        this.lon = lon;
        on = true;
    }

    public void clear() {
        on = false;
    }

    public boolean isOn() {
        return on;
    }

    public double lat() {
        return lat;
    }

    public double lon() {
        return lon;
    }

    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (shadow || !on) return;
        float w = c.getWidth(), h = c.getHeight();
        float cx = w / 2f, cy = h / 2f;
        Point p = new Point();
        map.getProjection().toPixels(new GeoPoint(lat, lon), p);
        float dx = p.x - cx, dy = p.y - cy;
        double len = Math.hypot(dx, dy);
        IGeoPoint ctr = map.getProjection().fromPixels((int) cx, (int) cy);
        double meters = Geo.haversine(ctr.getLatitude(), ctr.getLongitude(), lat, lon);
        if (len < 2) {
            c.drawCircle(cx, cy, 14f * d, markRing);
            c.drawCircle(cx, cy, 10f * d, mark);
            return;
        }
        // keep coordinates sane when the target is extremely far away
        float lim = 4000f * d;
        float ex = p.x, ey = p.y;
        if (len > lim) {
            ex = (float) (cx + dx / len * lim);
            ey = (float) (cy + dy / len * lim);
        }
        c.drawLine(cx, cy, ex, ey, halo);
        c.drawLine(cx, cy, ex, ey, line);

        float m = 30f * d;
        boolean inside = p.x > m && p.x < w - m && p.y > m && p.y < h - m;
        float lx, ly; // end of the visible part of the line
        if (inside) {
            c.drawCircle(p.x, p.y, 11f * d, markRing);
            c.drawCircle(p.x, p.y, 8f * d, mark);
            lx = p.x;
            ly = p.y;
        } else {
            float sx = Math.abs(dx) < 1e-3 ? Float.MAX_VALUE : (cx - m) / Math.abs(dx);
            float sy = Math.abs(dy) < 1e-3 ? Float.MAX_VALUE : (cy - m) / Math.abs(dy);
            float s = Math.min(sx, sy);
            lx = cx + dx * s;
            ly = cy + dy * s;
            double ang = Math.atan2(dy, dx);
            float a = 13f * d;
            arrow.rewind();
            arrow.moveTo((float) (lx + Math.cos(ang) * a), (float) (ly + Math.sin(ang) * a));
            arrow.lineTo((float) (lx + Math.cos(ang + 2.5) * a), (float) (ly + Math.sin(ang + 2.5) * a));
            arrow.lineTo((float) (lx + Math.cos(ang - 2.5) * a), (float) (ly + Math.sin(ang - 2.5) * a));
            arrow.close();
            c.drawPath(arrow, markRing);
            c.save();
            c.scale(0.72f, 0.72f, lx, ly);
            c.drawPath(arrow, mark);
            c.restore();
        }
        // distance label in the middle of the visible line
        String s = meters >= 1000 ? String.format(Locale.US, "%.2f km", meters / 1000) : String.format(Locale.US, "%.0f m", meters);
        float mx = (cx + lx) / 2f, my = (cy + ly) / 2f;
        float tw = txt.measureText(s);
        float padX = 9f * d, hh = 15f * d;
        mx = Math.max(tw / 2 + padX + 4 * d, Math.min(w - tw / 2 - padX - 4 * d, mx));
        my = Math.max(hh + 4 * d, Math.min(h - hh - 4 * d, my));
        rc.set(mx - tw / 2 - padX, my - hh, mx + tw / 2 + padX, my + hh);
        c.drawRoundRect(rc, hh, hh, pill);
        c.drawText(s, mx, my + 4.6f * d, txt);
    }
}
