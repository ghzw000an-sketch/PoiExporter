package iq.gis.poiexporter;

import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;

import org.json.JSONArray;
import org.json.JSONObject;
import org.osmdroid.tileprovider.modules.SqlTileWriter;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.MapTileIndex;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Maps added by the user from the internet (XYZ tile links). Each one is either a base map or a
 * view-only overlay layer drawn above the base map, and can be downloaded for offline use.
 */
public final class MapSources {
    public static final int MAX_TILES = 50000;
    private static final String[] SUB = {"a", "b", "c"};
    private static SqlTileWriter writer;

    private MapSources() {
    }

    public static final class Item {
        public String id = "", name = "", url = "";
        public boolean overlay, visible = true, noBulk;
        public int opacity = 100, minZ = 0, maxZ = 19;
    }

    public static final class Preset {
        public final String ar, en, url;
        public final boolean overlay;
        public final int maxZ;

        Preset(String ar, String en, String url, boolean overlay, int maxZ) {
            this.ar = ar;
            this.en = en;
            this.url = url;
            this.overlay = overlay;
            this.maxZ = maxZ;
        }

        public String label() {
            return S.t(ar, en);
        }
    }

    public static final Preset[] PRESETS = {
            new Preset("OpenTopoMap (تضاريس)", "OpenTopoMap (terrain)", "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png", false, 17),
            new Preset("Esri شوارع", "Esri Streets", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}", false, 19),
            new Preset("Esri طبوغرافية", "Esri Topographic", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}", false, 19),
            new Preset("CARTO Voyager", "CARTO Voyager", "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png", false, 19),
            new Preset("أسماء وحدود (طبقة)", "Places & boundaries (overlay)", "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}", true, 19),
            new Preset("OpenStreetMap فرنسا", "OpenStreetMap France", "https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png", false, 19),
            new Preset("خريطة إنسانية (HOT)", "Humanitarian (HOT)", "https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png", false, 19),
            new Preset("CyclOSM (دراجات)", "CyclOSM (cycling)", "https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png", false, 20),
            new Preset("USGS طبوغرافية (أمريكا)", "USGS Topo (USA)", "https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}", false, 16),
            new Preset("USGS صور جوية (أمريكا)", "USGS Imagery (USA)", "https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}", false, 16),
            new Preset("USGS صور + طبوغرافية (أمريكا)", "USGS Imagery Topo (USA)", "https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryTopo/MapServer/tile/{z}/{y}/{x}", false, 16),
            new Preset("ظلال التضاريس USGS (طبقة)", "USGS shaded relief (overlay)", "https://basemap.nationalmap.gov/arcgis/rest/services/USGSShadedReliefOnly/MapServer/tile/{z}/{y}/{x}", true, 16),
            new Preset("مسارات الدراجات (طبقة)", "Cycling routes (overlay)", "https://tile.waymarkedtrails.org/cycling/{z}/{x}/{y}.png", true, 18),
            new Preset("مسارات المشي (طبقة)", "Hiking trails (overlay)", "https://tile.waymarkedtrails.org/hiking/{z}/{x}/{y}.png", true, 18),
            new Preset("خرائط البحر (طبقة)", "Sea marks (overlay)", "https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png", true, 18),
    };

    // ------------------------------------------------------------------ storage

    public static List<Item> load(Prefs p) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.get("maps", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.id = o.getString("id");
                it.name = o.optString("name", "");
                it.url = o.getString("url");
                it.overlay = o.optBoolean("overlay", false);
                it.visible = o.optBoolean("visible", true);
                it.noBulk = o.optBoolean("noBulk", false);
                it.opacity = o.optInt("opacity", 100);
                it.minZ = o.optInt("minZ", 0);
                it.maxZ = o.optInt("maxZ", 19);
                out.add(it);
            }
        } catch (Exception ignored) {
            // damaged list: start empty
        }
        return out;
    }

    public static void save(Prefs p, List<Item> list) {
        JSONArray a = new JSONArray();
        try {
            for (Item it : list) {
                JSONObject o = new JSONObject();
                o.put("id", it.id);
                o.put("name", it.name);
                o.put("url", it.url);
                o.put("overlay", it.overlay);
                o.put("visible", it.visible);
                o.put("noBulk", it.noBulk);
                o.put("opacity", it.opacity);
                o.put("minZ", it.minZ);
                o.put("maxZ", it.maxZ);
                a.put(o);
            }
        } catch (Exception ignored) {
            // cannot happen with plain values
        }
        p.put("maps", a.toString());
    }

    /** Adds the sources of an .aqx file that can be used as plain XYZ links. Returns {added, skipped}. */
    public static int[] importAqx(Prefs p, InputStream in) throws Exception {
        iq.gis.poiexporter.core.AqxParser.Result r = iq.gis.poiexporter.core.AqxParser.parse(in);
        List<Item> list = load(p);
        int added = 0, dup = 0;
        for (iq.gis.poiexporter.core.AqxParser.Entry e : r.entries) {
            if (!validUrl(e.url)) continue;
            boolean have = false;
            for (Item it : list) if (it.url.equals(e.url) && it.overlay == e.overlay) have = true;
            if (have) {
                dup++;
                continue;
            }
            Item it = new Item();
            it.id = "q" + System.currentTimeMillis() + "_" + added;
            it.name = e.name;
            it.url = e.url;
            it.overlay = e.overlay;
            it.noBulk = e.noBulk;
            it.minZ = e.minZ;
            it.maxZ = Math.max(e.maxZ, e.minZ);
            it.visible = false; // imported maps start hidden; switch them on from the list
            list.add(it);
            added++;
        }
        save(p, list);
        return new int[]{added, r.skipped.size() + dup};
    }

    public static Item find(Prefs p, String id) {
        for (Item it : load(p)) if (it.id.equals(id)) return it;
        return null;
    }

    public static boolean validUrl(String u) {
        String s = u == null ? "" : u.trim().toLowerCase(Locale.US);
        return (s.startsWith("http://") || s.startsWith("https://")) && s.contains("{z}") && s.contains("{x}")
                && (s.contains("{y}") || s.contains("{-y}"));
    }

    /** Sources whose terms forbid bulk downloading. */
    public static boolean bulkBlocked(String url) {
        String s = url.toLowerCase(Locale.US);
        return s.contains("tile.openstreetmap.org") || s.contains("google.com") || s.contains("googleapis.com");
    }

    // ------------------------------------------------------------------ tile source

    private static String fill(String url, long t) {
        int z = MapTileIndex.getZoom(t), x = MapTileIndex.getX(t), y = MapTileIndex.getY(t);
        return url.replace("{z}", String.valueOf(z)).replace("{x}", String.valueOf(x))
                .replace("{-y}", String.valueOf(((1 << z) - 1) - y)).replace("{y}", String.valueOf(y))
                .replace("{s}", SUB[(x + y) % SUB.length]);
    }

    public static OnlineTileSourceBase source(Item it) {
        final String url = it.url.trim();
        String low = url.toLowerCase(Locale.US);
        String ext = low.contains(".jpg") || low.contains(".jpeg") ? ".jpg" : ".png";
        String base = url;
        int br = base.indexOf('{');
        if (br > 0) base = base.substring(0, br);
        if (base.isEmpty()) base = "https://";
        return new OnlineTileSourceBase("C_" + it.id, it.minZ, it.maxZ, 256, ext, new String[]{base}) {
            @Override
            public String getTileURLString(long t) {
                return fill(url, t);
            }
        };
    }

    public static ColorMatrixColorFilter opacityFilter(int percent) {
        float a = Math.max(0f, Math.min(1f, percent / 100f));
        return new ColorMatrixColorFilter(new ColorMatrix(new float[]{
                1, 0, 0, 0, 0,
                0, 1, 0, 0, 0,
                0, 0, 1, 0, 0,
                0, 0, 0, a, 0}));
    }

    // ------------------------------------------------------------------ offline download

    static synchronized SqlTileWriter writer() {
        if (writer == null) writer = new SqlTileWriter();
        return writer;
    }

    private static int tileX(double lon, int z) {
        double n = Math.pow(2, z);
        int x = (int) Math.floor((lon + 180.0) / 360.0 * n);
        return Math.max(0, Math.min((int) n - 1, x));
    }

    private static int tileY(double lat, int z) {
        double l = Math.max(-85.0511, Math.min(85.0511, lat));
        double r = Math.toRadians(l), n = Math.pow(2, z);
        int y = (int) Math.floor((1.0 - Math.log(Math.tan(r) + 1.0 / Math.cos(r)) / Math.PI) / 2.0 * n);
        return Math.max(0, Math.min((int) n - 1, y));
    }

    /** bb = {south, west, north, east}. */
    public static long countTiles(double[] bb, int z1, int z2) {
        long total = 0;
        for (int z = z1; z <= z2; z++) {
            long w = tileX(bb[3], z) - tileX(bb[1], z) + 1L;
            long h = tileY(bb[0], z) - tileY(bb[2], z) + 1L;
            total += Math.max(0, w) * Math.max(0, h);
        }
        return total;
    }

    public static final class Job {
        public volatile boolean cancel;
    }

    public interface Progress {
        void update(int done, int total, int failed);

        void finished(boolean cancelled, int done, int failed, int total);
    }

    /** Downloads the tiles of the area into osmdroid's tile cache so the map works without internet. */
    public static void download(final Item it, final double[] bb, final int z1, final int z2, final Job job,
                                final Progress pg) {
        final OnlineTileSourceBase src = source(it);
        final int nz = z2 - z1 + 1;
        final int[] xs = new int[nz], ys = new int[nz], ws = new int[nz];
        final long[] cum = new long[nz + 1];
        for (int i = 0; i < nz; i++) {
            int z = z1 + i;
            xs[i] = tileX(bb[1], z);
            ys[i] = tileY(bb[2], z);
            ws[i] = Math.max(1, tileX(bb[3], z) - xs[i] + 1);
            int h = Math.max(1, tileY(bb[0], z) - ys[i] + 1);
            cum[i + 1] = cum[i] + (long) ws[i] * h;
        }
        final long total = cum[nz];
        final AtomicLong next = new AtomicLong(0);
        final AtomicInteger done = new AtomicInteger(0), fail = new AtomicInteger(0);
        final String ua = org.osmdroid.config.Configuration.getInstance().getUserAgentValue();
        final SqlTileWriter w = writer();
        final int workers = 4;
        final Thread[] ts = new Thread[workers];
        for (int k = 0; k < workers; k++) {
            ts[k] = new Thread(new Runnable() {
                public void run() {
                    byte[] buf = new byte[16384];
                    while (!job.cancel) {
                        long n = next.getAndIncrement();
                        if (n >= total) break;
                        int zi = 0;
                        while (zi < nz - 1 && n >= cum[zi + 1]) zi++;
                        long local = n - cum[zi];
                        int x = xs[zi] + (int) (local % ws[zi]);
                        int y = ys[zi] + (int) (local / ws[zi]);
                        long idx = MapTileIndex.getTileIndex(z1 + zi, x, y);
                        boolean ok = false;
                        HttpURLConnection c = null;
                        try {
                            c = (HttpURLConnection) new URL(src.getTileURLString(idx)).openConnection();
                            c.setConnectTimeout(15000);
                            c.setReadTimeout(20000);
                            c.setRequestProperty("User-Agent", ua);
                            if (c.getResponseCode() == 200) {
                                InputStream in = c.getInputStream();
                                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                                int r;
                                while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
                                in.close();
                                byte[] data = bo.toByteArray();
                                if (data.length > 0) {
                                    long exp = System.currentTimeMillis() + 365L * 24 * 3600 * 1000;
                                    synchronized (w) {
                                        ok = w.saveFile(src, idx, new ByteArrayInputStream(data), exp);
                                    }
                                }
                            }
                        } catch (Exception ignored) {
                            // counted as a failed tile
                        } finally {
                            if (c != null) c.disconnect();
                        }
                        int d = done.incrementAndGet();
                        if (!ok) fail.incrementAndGet();
                        if (d % 25 == 0 || d == total) pg.update(d, (int) total, fail.get());
                    }
                }
            });
            ts[k].start();
        }
        new Thread(new Runnable() {
            public void run() {
                for (Thread t : ts) {
                    try {
                        t.join();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
                pg.finished(job.cancel, done.get(), fail.get(), (int) total);
            }
        }).start();
    }

    // ------------------------------------------------------------------ cache size

    public static long dirSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long s = 0;
        File[] fs = f.listFiles();
        if (fs != null) for (File c : fs) s += dirSize(c);
        return s;
    }

    public static String fmtBytes(long b) {
        if (b >= 1024L * 1024 * 1024) return String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024 * 1024));
        if (b >= 1024L * 1024) return String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024));
        return String.format(Locale.US, "%d KB", b / 1024);
    }
}
