import iq.gis.poiexporter.core.*;
import java.io.*;

/** Checks the AQX parser on coretest/sample.aqx. Exits with 1 on any mismatch. */
public class AqxTest {
    static int fails = 0;

    static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) fails++;
    }

    public static void main(String[] a) throws Exception {
        AqxParser.Result r;
        try (InputStream in = new FileInputStream(a[0])) {
            r = AqxParser.parse(in);
        }
        check(r.title.equals("Sample maps"), "title");
        check(r.entries.size() == 4, "4 usable entries (got " + r.entries.size() + ")");
        check(r.skipped.size() == 2, "2 skipped: private token + vendor server (got " + r.skipped + ")");
        AqxParser.Entry e0 = r.entries.get(0);
        check(e0.url.equals("https://tile.example.org/{z}/{x}/{y}.png") && !e0.overlay && !e0.noBulk && e0.minZ == 1 && e0.maxZ == 19, "plain xyz converted");
        AqxParser.Entry e1 = r.entries.get(1), e2 = r.entries.get(2);
        check(e1.name.equals("Two zoom groups (1-9)") && e1.url.equals("https://low.example.org/{z}/{y}/{x}") && e1.noBulk, "first zoom group");
        check(e2.name.equals("Two zoom groups (10-12)") && e2.minZ == 10 && e2.maxZ == 12, "second zoom group, list range");
        check(r.entries.get(3).overlay, "hillshade is an overlay");
        if (fails > 0) System.exit(1);
    }
}
