import iq.gis.poiexporter.core.*;
import java.io.*;
import java.util.*;

/** Writes sample GeoJSON / GPX / DXF files so they can be checked by an independent parser. */
public class WritersTest {
    public static void main(String[] a) throws Exception {
        String out = a[0];
        LayerData pts = new LayerData("p", "مستشفيات \"Hospitals\"", Feature.POINT);
        Feature p = Feature.point(33.3152, 44.3661);
        p.name = "مستشفى الكرخ & <مركز>"; p.type = "hospital"; p.category = "مستشفيات"; p.nahiya = "ناحية 1"; p.qadaa = "قضاء الكرخ"; p.notes = "سطر1\nسطر2";
        pts.features.add(p);
        LayerData lines = new LayerData("l", "طرق", Feature.LINE);
        Feature l = new Feature(); l.geom = Feature.LINE; l.name = "شارع حيفا"; l.type = "primary";
        l.addPart(new double[]{44.30, 33.30, 44.31, 33.31, 44.33, 33.32}, false); l.lon = 44.31; l.lat = 33.31; lines.features.add(l);
        LayerData polys = new LayerData("g", "حدود", Feature.POLYGON);
        Feature g = new Feature(); g.geom = Feature.POLYGON; g.name = "ملعب"; g.type = "pitch";
        g.addPart(new double[]{44.0, 33.0, 44.1, 33.0, 44.1, 33.1, 44.0, 33.1}, false);       // not closed on purpose
        g.addPart(new double[]{44.02, 33.02, 44.05, 33.02, 44.05, 33.05, 44.02, 33.02}, true); // hole
        g.addPart(new double[]{45.0, 33.0, 45.1, 33.0, 45.1, 33.1, 45.0, 33.0}, false);       // 2nd polygon
        g.lon = 44.05; g.lat = 33.05; polys.features.add(g);
        List<LayerData> all = Arrays.asList(pts, lines, polys);
        try (OutputStream o = new FileOutputStream(out + "/t.geojson")) { GeoJsonWriter.write(all, o); }
        try (OutputStream o = new FileOutputStream(out + "/t.gpx")) { GpxWriter.write(all, o); }
        try (OutputStream o = new FileOutputStream(out + "/t.dxf")) { DxfWriter.write(all, o); }
        System.out.println("ok");
    }
}
